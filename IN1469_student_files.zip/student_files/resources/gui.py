"""

    gui.py   -   A super-thin wrapper around the PySimpleGUI library
                 To use:

                 import resources.gui as gui
                 result = gui.simple_input(label, title, default_input_value)
                 gui.simple_popup(result)


"""
import PySimpleGUI as sg


def simple_input(field_label: str = 'Value',
                 title: str = 'Query',
                 default_input_value: str = '',
                 button_labels: list[sg.Button] = None) -> str:
    if not button_labels:
        button_labels = [sg.Submit(), sg.Cancel()]
    layout = [
                 [sg.Text(field_label)],
                 [sg.InputText(default_input_value)],
                 button_labels
             ]

    window = sg.Window(title, layout)
    event, results = window.read()
    window.close()

    return results[0] if event == 'Submit' else None


def simple_popup(display_msg: str = 'No input.', field_label: str = 'Value: ') -> None:
    sg.popup(field_label, display_msg)
