"""

    Run this to restore the database, if needed.

"""
import csv
from pathlib import Path
import sqlite3
import sys

resources = [
    {
        'data_file': 'accounts.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS accounts (id VARCHAR(10) NOT NULL PRIMARY KEY, name VARCHAR(150), balance float, rate float, acct_type VARCHAR(5))',
        'insert_stmt': 'INSERT INTO accounts(id, name, balance, rate, acct_type) VALUES (?,?,?,?,?)'
    },
    {
        'data_file': 'airports.dat',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS airports (airportid VARCHAR(10) NOT NULL PRIMARY KEY, name VARCHAR(100), city VARCHAR(100), country VARCHAR(15), IATA_FAA VARCHAR(50), ICAO VARCHAR(50), latitude VARCHAR(50), longitude VARCHAR(50), altitude VARCHAR(50), timezone VARCHAR(50), dst VARCHAR(50), tz VARCHAR(50))',
        'insert_stmt': 'INSERT INTO airports(airportid, name, city, country, IATA_FAA, ICAO, latitude, longitude, altitude, timezone, dst, tz) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'cities15000.txt',
        'skip_lines': False,
        'delimiter': '\t',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS cities15000 (geonameid VARCHAR(10) NOT NULL PRIMARY KEY, name VARCHAR(500), asciiname VARCHAR(100), alternatenames VARCHAR(500), latitude VARCHAR(50), longitude VARCHAR(50), feature_class VARCHAR(50), feature_code VARCHAR(50), country_code VARCHAR(50), cc2 VARCHAR(50), admin_code1 VARCHAR(50), admin_code2 VARCHAR(50), admin_code3 VARCHAR(50), admin_code4 VARCHAR(50), population VARCHAR(50), elevation VARCHAR(50), dem VARCHAR(50), timezone VARCHAR(50), modification_date VARCHAR(50))',
        'insert_stmt': 'INSERT INTO cities15000(geonameid, name, asciiname, alternatenames, latitude, longitude, feature_class, feature_code, country_code, cc2, admin_code1, admin_code2, admin_code3, admin_code4, population, elevation, dem, timezone, modification_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'countryinfo.txt',
        'skip_lines': 51,
        'delimiter': '\t',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS countryinfo (iso VARCHAR(10) NOT NULL PRIMARY KEY, iso3 VARCHAR(10), iso_numeric VARCHAR(10), fips VARCHAR(200), country VARCHAR(200), capital VARCHAR(50), area_sq_km INTEGER, population INTEGER, continent VARCHAR(100), tld VARCHAR(100), currency_code VARCHAR(100), currency_name VARCHAR(100), phone VARCHAR(100), postal_code_format VARCHAR(100), postal_code_regex VARCHAR(100), languages VARCHAR(100), geonameid VARCHAR(10), neighbours VARCHAR(100), equivalent_fips_code VARCHAR(10))',
        'insert_stmt': 'INSERT INTO countryinfo(iso, iso3, iso_numeric, fips, country, capital, area_sq_km, population, continent, tld, currency_code, currency_name, phone, postal_code_format, postal_code_regex, languages, geonameid, neighbours, equivalent_fips_code) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'diamonds.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS diamonds (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, carat FLOAT, cut VARCHAR(50), color VARCHAR(10), clarity VARCHAR(20), depth FLOAT, tbl INTEGER, price INTEGER, x FLOAT, y FLOAT, z FLOAT)',
        'insert_stmt': 'INSERT INTO diamonds(carat, cut, color, clarity, depth, tbl, price, x, y, z) VALUES (?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'netflix_titles.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS netflix_titles (show_id VARCHAR(10) NOT NULL PRIMARY KEY, type VARCHAR(20), title VARCHAR(60), director VARCHAR(50), cast VARCHAR(250), country VARCHAR(40), date_added VARCHAR(40), release_year VARCHAR(10), rating VARCHAR(10), duration VARCHAR(20), listed_in VARCHAR(250), description VARCHAR(500))',
        'insert_stmt': 'INSERT INTO netflix_titles(show_id, type, title, director, cast, country, date_added, release_year, rating, duration, listed_in, description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'mpg.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS mpg (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, mpg FLOAT, cylinders INTEGER, displacement FLOAT, horsepower FLOAT, weight INTEGER, acceleration FLOAT, model_year INTEGER, origin VARCHAR(50), name VARCHAR(50))',
        'insert_stmt': 'INSERT INTO mpg(mpg, cylinders, displacement, horsepower, weight, acceleration, model_year, origin, name) VALUES (?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'planets.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS planets (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, method VARCHAR(100), number INTEGER, orbital_period FLOAT, mass FLOAT, distance FLOAT, year INTEGER)',
        'insert_stmt': 'INSERT INTO planets(method, number, orbital_period, mass, distance, year) VALUES (?,?,?,?,?,?)'
    },
    {
        'data_file': 'richest_athletes.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS richest_athletes (SNo VARCHAR(10) NOT NULL PRIMARY KEY, Name VARCHAR(60), Nationality VARCHAR(25), CurrentRank VARCHAR(10), PreviousYearRank VARCHAR(20), Sport VARCHAR(50), Year VARCHAR(15), Earnings REAL)',
        'insert_stmt': 'INSERT INTO richest_athletes(SNo, Name, Nationality, CurrentRank, PreviousYearRank, Sport, Year, Earnings) VALUES (?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'Schools.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS schools (school_id VARCHAR(30) NOT NULL PRIMARY KEY, fullname VARCHAR(100), city VARCHAR(50), state VARCHAR(15), country VARCHAR(50))',
        'insert_stmt': 'INSERT INTO schools(school_id, fullname, city, state, country) VALUES (?,?,?,?,?)'
    },
    {
        'data_file': 'simpsons.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS simpsons (id VARCHAR(10) NOT NULL PRIMARY KEY, name VARCHAR(50), actor VARCHAR(150), role VARCHAR(250), episode_debut VARCHAR(100), original_air_date VARCHAR(100))',
        'insert_stmt': 'INSERT INTO simpsons(id, name, actor, role, episode_debut, original_air_date) VALUES (?,?,?,?,?,?)'
    },
    {
        'data_file': 'titanic.csv',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS titanic (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, survived integer, pclass integer, sex VARCHAR(20), age float, sibsp integer, parch integer, fare float, embarked VARCHAR(10), class VARCHAR(10), who VARCHAR(10), adult_male VARCHAR(10), deck VARCHAR(10), embark_town VARCHAR(10), alive  VARCHAR(10), alone VARCHAR(10))',
        'insert_stmt': 'INSERT INTO titanic(survived, pclass, sex, age, sibsp, parch, fare, embarked, class, who, adult_male, deck, embark_town, alive, alone) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    },
    {
        'data_file': 'movies.csv',
        'skip_lines': False,
        'create_stmt': 'CREATE TABLE IF NOT EXISTS movies (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, title VARCHAR(150), release_date VARCHAR(30), runtime integer, budget integer, revenue integer, tagline VARCHAR(300))',
        'insert_stmt': 'INSERT INTO movies(title, release_date, runtime, budget, revenue, tagline) VALUES (?,?,?,?,?,?)'
    }
]


def create_db_table(resource: dict):
    """
    Processes incoming data.  Reads the specified file.  Inserts it into the database.
    :param resource: dict - requires 'data_file', 'create_stmt', and 'insert_stmt' keys.
                            Provide a 'table' key if table name is different than the filename stem.
                            Optional 'skip_lines', 'delimiter', and 'encoding' keys may be provided.
    :return: None
    """
    db_file = 'course_data.db'

    data_filename = resource.get('data_file')
    table = resource.get('table', Path(data_filename).stem.lower())
    create_stmt = resource.get('create_stmt')
    insert_stmt = resource.get('insert_stmt')
    skip_lines = resource.get('skip_lines', True)
    delimiter = resource.get('delimiter', ',')
    encoding = resource.get('encoding', 'utf-8-sig')

    if not all([data_filename, table, create_stmt, insert_stmt]):
        print(f'\n{data_filename} does not provide a file name (data_file), a table name, a create statement (create_stmt), and an insert statement (insert_stmt).\n\n')
        return

    data_filename = Path(data_filename)
    data = []

    try:
        with open(data_filename, mode='rt', encoding=encoding) as f:
            print(f'\nReading data from {data_filename}')
            try:
                reader = csv.reader(f, delimiter=delimiter)
                for row in reader:
                    data.append(row)
            except (UnicodeDecodeError, csv.Error) as err:
                print(f'Data reading error: {err}.  Problem occurred on line: {reader.line_num}.')
                raise IOError() from err
    except IOError as err:
        print(f'IOError: {err}')
        return

    if skip_lines:
        if isinstance(skip_lines, bool):
            skip_lines = 1
        elif isinstance(skip_lines, int):
            pass
        else:
            print('skip_lines should be either a Boolean (to skip 1 line) or an int.')
            return
        data = data[skip_lines:]

    print(f'File read complete: {data_filename}, {len(data)} lines read.')

    try:
        with sqlite3.connect(db_file) as connection:
            print(f'Database {db_file} connection opened.')
            cursor = connection.cursor()
            cursor.execute(f'DROP TABLE IF EXISTS {table}')         # table does not come from an untrusted source
            print('--> Table dropped')
            cursor.execute(create_stmt)
            print('--> New table created')
            for row in data:
                cursor.execute(insert_stmt, row)
            print(f'--> File data inserted (loaded into {table} table of {db_file}).')
    except Exception as err:
        print('Warning: ', f'{data_filename.name} data NOT loaded into {db_file}')
        print(f'Database Error (Type: {type(err)})\nError: {err}', file=sys.stderr)
        print(f'Row: {row}')
        print(f'Insert Statement: {insert_stmt}')
    finally:
        connection.close()
        print(f'Database {db_file} closed')


for resource in resources:
    create_db_table(resource)
