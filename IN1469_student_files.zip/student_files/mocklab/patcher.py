import json
from contextlib import closing
from pathlib import Path
import sqlite3
import sys

patched_items = {}


def patch(module, attr, newitem):
    olditem = getattr(module, attr, object())
    if olditem is not object():
        patched_items[(module, attr)] = olditem
    setattr(module, attr, newitem)


class RequestsGet:
    """Simulates requests.get().  Used specifically for movie exercise for this course."""
    def __init__(self):
        self.response = None

    def __call__(self, *args, **kwargs):
        self.requests_get(*args, **kwargs)
        return self

    def requests_get(self, url='', params=None, **kwargs):
        is_search = True if url.find('query') != -1 else False
        if is_search:
            sql = 'SELECT results FROM title_search WHERE title=?'
            params = (url.split('query=')[1],)
        else:
            sql = 'SELECT details FROM details_search WHERE id=?'
            params = (url.rsplit('/')[-1].split('?')[0],)

        data_file = Path(__file__).parent / 'tmdb_lab.db'
        with closing(sqlite3.connect(data_file)) as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            results = cursor.fetchone()
            if results:
                self.response = results[0]
            else:
                if is_search:
                    self.response = '{"page":1,"results":[],"total_pages":0,"total_results":0}'
                    cursor.execute('select title from title_search')
                    results = ', '.join([title[0] for title in cursor])
                    print(f'Only the following movies may be searched for when using the mocked solution: {results}', file=sys.stderr)
                else:
                    print(f'Movie not found.  Check that you provided the id properly.  Id used was: {params[0]}', file=sys.stderr)

    def json(self):
        return json.loads(self.text)

    @property
    def text(self):
        return self.response
