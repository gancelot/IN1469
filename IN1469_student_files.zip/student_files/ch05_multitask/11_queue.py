"""

    11_queue.py

"""
from queue import Queue
from threading import Thread

import requests
from bs4 import BeautifulSoup

num_worker_threads = 20
tasks = ['https://requests.readthedocs.io/en/latest/', 'https://automatetheboringstuff.com', 'https://pypi.python.org',
         'https://realpython.com/', 'https://www.practicepython.org/', 'https://love-python.blogspot.com/',
         'https://planetpython.org/', 'https://www.python.org/doc/humor/', 'https://lucumr.pocoo.org/',
         'https://doughellmann.com/blog/', 'https://pymotw.com/3/', 'https://python-history.blogspot.com/',
         'https://nothingbutsnark.svbtle.com/', 'https://www.pydanny.com/', 'https://pythontips.com/',
         'https://www.blog.pythonlibrary.org/']


def get_data(url):
    try:
        text = requests.get(url).text
        soup = BeautifulSoup(text, 'html.parser')
        result = soup.title.text
    except (TypeError, requests.exceptions.ConnectionError) as err:
        result = err.args[0]

    return result


req_queue = Queue()
results_queue = Queue()
for url in tasks:
    req_queue.put(url)


class WorkerThread(Thread):
    def run(self):
        while not req_queue.empty():
            url = req_queue.get()
            results_queue.put(get_data(url))
            req_queue.task_done()


for i in range(num_worker_threads):
    t = WorkerThread()
    t.start()


req_queue.join()       # don't end main thread until all tasks are finished

while not results_queue.empty():
    print(results_queue.get())
    results_queue.task_done()
