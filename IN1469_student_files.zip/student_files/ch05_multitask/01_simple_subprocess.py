"""

    01_simple_subprocess.py

"""
import subprocess


# subprocess.run(['echo', 'hello'])                # POSIX
subprocess.run(['echo', 'hello'], shell=True)      # Windows
