"""
        task5_2_starter.py  -   Modify the SMTPDManager to be a context manager that
                                starts and stops automatically in a with-control
"""
import logging
import smtplib
import subprocess
import sys
import time
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from pathlib import Path

import psutil
from reportlab.lib.colors import Color, green, lavenderblush, dimgray
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

import resources.gui as gui

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def get_data(filepath: str | Path) -> list[tuple]:
    data = [('Name', 'City', 'State')]
    with Path(filepath).open(encoding='utf-8') as f:
        f.readline()
        for line in f:
            fields = line.split(',')
            if len(fields) == 5:
                name, city, state = fields[1], fields[2], fields[3]
                data.append((name, city, state))
    logger.info(f'Data loaded from {filepath}')
    return data


def generate_pdf(data: list[tuple], filename: str | Path) -> None:
    doc_items = []

    doc = SimpleDocTemplate(str(filename), pagesize=letter, rightMargin=72,
                            leftMargin=72, topMargin=72, bottomMargin=72)

    table = Table(data, colWidths=(250, 200, 60))

    table_style_format = [
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),                           # Header alignment
        ('TEXTCOLOR', (0, 0), (-1, 0), green),                          # Header text
        ('BACKGROUND', (0, 0), (-1, 0), lavenderblush),                 # Header background color
        ('ALIGN', (0, 1), (-1, -1), 'LEFT'),                            # Data (body) alignment
        ('GRID', (0, 0), (-1, -1), 1, dimgray),                         # Data (body) gridlines on
        ('BACKGROUND', (0, 1), (-1, -1), Color(0.94, 0.92, 0.90))       # Data (body) background color
    ]

    ts = TableStyle(table_style_format)
    table.setStyle(ts)
    doc_items.append(table)
    doc.build(doc_items)
    logger.info(f'{filename} generated.')


def send_email(sender: str, receiver: str, subj: str, attachment_fn: str | Path) -> bool:
    status = False
    email_msg = MIMEMultipart()

    email_msg['Subject'] = subj
    email_msg['From'] = sender
    email_msg['To'] = receiver

    try:
        attachment = Path(attachment_fn)
        part = MIMEApplication(attachment.read_text(), Name=attachment.name)
        part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
        email_msg.attach(part)

        server = smtplib.SMTP('localhost', 1025)
        server.send_message(email_msg)
        server.quit()

        logger.info('Email and attachment sent.')
        status = True
    except ConnectionRefusedError:
        logger.error(f'Email not sent.  Your server is likely not running.')
    except Exception as err:
        logger.error('Email not sent.')
        logger.error(f'{type(err)}: {err}')

    return status


class SMTPDManager:
    aiosmtpd_cmd = 'python -m aiosmtpd -n -l localhost:1025'
    smtpd_cmd = 'python -m smtpd -c DebuggingServer -n localhost:1025'

    def __init__(self, delay: int = 2):
        self.proc = None
        self.delay = delay
        command_str = self.aiosmtpd_cmd if sys.version_info[1] >= 12 else self.smtpd_cmd
        self.command = [sys.executable, *command_str.split()[1:]]

    # Step 1. Add an __enter__() method


    # Step 2. Add an __exit__() method


    def start(self):
        logger.info(f'Starting server using {self.command}')
        self.proc = subprocess.Popen(self.command)
        time.sleep(self.delay)

    def stop(self):
        if self.proc:
            proc = psutil.Process(self.proc.pid)
            proc.kill()
            time.sleep(self.delay)
            logger.info(f'Stopping server.')
            if psutil.pid_exists(self.proc.pid):
                logger.info('Server not stopped.')
            else:
                logger.info('Server stopped.')
            self.proc = None


if __name__ == '__main__':

    logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                        handlers=[logging.StreamHandler(stream=sys.stdout)])

    data_file = '../resources/baseball/Schools.csv'
    result = gui.simple_input(default_input_value=data_file)
    if result:
        data_file = Path(data_file)
        pdf_file = Path(data_file.stem + '.pdf')
        file_data = get_data(result)
        generate_pdf(file_data, pdf_file)

        # Step 3. Remove the instantiation, sm.start(), and sm.stop() statements.
        #         Replace it with a with-control
        sm = SMTPDManager()
        sm.start()

        if send_email(sender='joe@example.com', receiver='dave@example.com',
                      subj='Task5-2 PDF within Email, Auto-Launch Subprocess as Context Manager',
                      attachment_fn=str(pdf_file)):
            logger.info('Email sent.')

        sm.stop()
    else:
        logger.info('Action canceled.')
