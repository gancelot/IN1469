"""

    07_threading.py

"""
import logging
import sys
from threading import Thread

import requests

logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def load_data(url):
    data = None
    try:
        r = requests.get(url)
        data = r.json()
    except requests.exceptions.RequestException as err:
        logging.error(f'Error retrieving data from {url}\nMessage: {err}')

    return data


class DataFetcher(Thread):
    def __init__(self, url, name=''):
        super().__init__(name=name)
        self.url = url

    def run(self):
        logging.info(f'Results: {load_data(self.url)}')


if __name__ == '__main__':
    m = DataFetcher('https://eonet.gsfc.nasa.gov/api/v3/events', 'Worker')
    m.start()
