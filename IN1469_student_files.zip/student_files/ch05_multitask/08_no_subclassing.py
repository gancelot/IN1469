"""

    08_no_subclassing.py

"""
import logging
import sys
from threading import Thread

import requests

logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def load_data(url):
    data = None
    try:
        r = requests.get(url)
        data = r.json()
        logging.info(data)
    except requests.exceptions.RequestException as err:
        logging.error(f'Error retrieving data from {url}\nMessage: {err}')

    return data


if __name__ == '__main__':
    m = Thread(target=load_data, args=('https://eonet.gsfc.nasa.gov/api/v3/events',))
    m.start()
