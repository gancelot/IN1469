import ray
import requests
from bs4 import BeautifulSoup

ray.init()

# Step 1. Mark our function with the remote decorator.  Telling ray that this function can become
#         scheduled.

def get_data(url: str) -> str:
    try:
        text = requests.get(url).text
        soup = BeautifulSoup(text, 'html.parser')
        result = soup.title.text
    except (TypeError, requests.exceptions.ConnectionError) as err:
        result = err.args[0]

    return result


tasks = ['https://requests.readthedocs.io/en/latest/', 'https://automatetheboringstuff.com', 'https://pypi.python.org',
         'https://realpython.com/', 'https://www.practicepython.org/', 'https://love-python.blogspot.com/',
         'https://planetpython.org/', 'https://www.python.org/doc/humor/', 'https://lucumr.pocoo.org/',
         'https://doughellmann.com/blog/', 'https://pymotw.com/3/', 'https://python-history.blogspot.com/',
         'https://nothingbutsnark.svbtle.com/', 'https://www.pydanny.com/', 'https://pythontips.com/',
         'https://www.blog.pythonlibrary.org/']


print('Starting jobs...')

# Step 2. Queue the jobs up: In a list comprehension, iterate over the tasks grabbing each url
#         one-by-one and calling func.remote() passing the url in each time.  Save the results
#         in a variable called obj_refs


# Step 3. Call ray.get() to retrieve the results of the calls to remote() passing in obj_refs.


print(*results, sep='\n')
ray.timeline(filename='timeline.json')

# open Chrome (not FF) to:  chrome://tracing/
# "Load" timeline.json.

ray.shutdown()
