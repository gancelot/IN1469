"""

    14_using_ray.py

    Note: as of this writing, the Ray library had not upgraded to Python 3.12 yet.
    It will run on 3.11, however.

    Until Ray is upgraded, you will have to switch to 3.11 to run this.
    To do this, you can create a Python virtual environment using 3.11 and then
    pip installing ray, beautifulsoup4 and requests.

"""
import os

import ray


@ray.remote
def square(val: int):
    return f'Square result: {val * val}, pid: {os.getpid()}'


ray.init()

obj_refs = [square.remote(i) for i in range(5, 10)]
results = ray.get(obj_refs)
print(*results, sep='\n')
ray.timeline(filename='timeline.json')

# open Chrome (not FF) to:  chrome://tracing/
# "Load" timeline.json.

ray.shutdown()
