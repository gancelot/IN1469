"""

    02_run_no_args.py

"""
import subprocess
import sys


result = subprocess.run([sys.executable, 'sample.py'])   # this will randomly return non-zero occassionally

try:
    result.check_returncode()
except subprocess.CalledProcessError as err:
    print(f'Error running command: {err}', file=sys.stderr)
