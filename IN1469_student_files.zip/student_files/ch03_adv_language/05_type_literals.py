"""

    05_type_literals.py     - Creating and using type literals

"""
from typing import Literal, get_args

# these can be placed into another module such as type_defs.py and imported
Size = Literal['Small', 'Medium', 'Large', 'Extra-Large']
CakeType = Literal['Chocolate', 'White', 'Carrot', 'Red Velvet', 'Lemon']


class CakeOrder:
    prices = [20, 40, 80, 100]

    def __init__(self, typ: CakeType, size: Size = 'Medium'):
        idx = get_args(Size).index(size)
        self.values = (self.prices[idx], typ, size)


order1 = CakeOrder('Chocolate')
print(order1.values)
order2 = CakeOrder('Red Velvet', 'Extra-Large')
print(order2.values)
# order3 = CakeOrder('Carrot', 'Big')                              # ValueError since 'Big' is not in Size
# print(order3.values)
