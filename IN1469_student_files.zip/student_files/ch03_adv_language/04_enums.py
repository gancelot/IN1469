"""

    04_enums.py     - Creating and using Enum types

"""
from enum import Enum, Flag


class Direction(Enum):      # can also do:   Direction = Enum('Direction', ['NORTH', 'SOUTH', 'EAST', 'WEST'])
    NORTH = 1
    EAST = 2
    SOUTH = 3
    WEST = 4

    @staticmethod
    def turn_right(faces):
        return Direction.NORTH if faces == Direction.WEST else Direction(faces.value + 1)


for member in Direction:
    print(member, member.name, member.value, sep=', ')


facing = Direction.NORTH
for turn in range(4):
    facing = Direction.turn_right(facing)
    print(facing)


print('A bitwise flag system:')


class Style(Flag):
    ITALIC = 1
    BOLD = 2
    UNDERLINE = 4
    UPPERCASE = 8


fmt = Style.ITALIC | Style.UPPERCASE | Style.UNDERLINE
print(fmt, fmt.name, fmt.value, sep='\n')
