"""
    08b_stringio_logger.py
    Temporarily attaches a StringIO() buffer to a logger and records log output to memory
    only during the with control.  After the with control, logs only go to console output.

"""
import sys
import logging
from io import StringIO

logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def attach_log_buffer(buffer: StringIO, logger: logging.Logger) -> logging.StreamHandler:
    handler = logging.StreamHandler(stream=buffer)
    logger.addHandler(handler)
    return handler


logging.info('This is only captured to the console')

with StringIO() as buf:
    logger = logging.getLogger()
    handler = attach_log_buffer(buf, logger)
    logging.info('This is captured to the console AND the StringIO object')
    print(buf.getvalue())
    logger.removeHandler(handler)

logging.info('This will not generate an error even though the buffer was closed.')
