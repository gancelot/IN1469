"""

    flushstringio.py

"""
import logging
import sys
from enum import Enum
from io import StringIO
from logging import Logger
from pathlib import Path

from multimethod import multimethod

logging.basicConfig(level=logging.INFO, format='--> %(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


class FlushStatus(Enum):
    FILE = 1                # save to file
    LOG = 2                 # log it
    DISCARD = 3             # discard it


class FlushStringIO(StringIO):
    def __init__(self, status: FlushStatus, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.status = status

    @multimethod
    def flush(self, filename: str):
        with Path(filename).open(mode='wt', encoding='utf-8') as f:
            f.write(self.getvalue())

    @multimethod
    def flush(self, logger: Logger):
        logger.info(self.getvalue())

    @multimethod
    def flush(self):
        pass

    def close(self):
        print(f'Closing...status: {self.status}')
        match self.status:
            case FlushStatus.FILE:
                self.flush('datafile.txt')
            case FlushStatus.LOG:
                self.flush(logging.getLogger())
            case FlushStatus.DISCARD:
                self.flush()

        super().close()


if __name__ == '__main__':
    with FlushStringIO(status=FlushStatus.FILE) as fs:
        fs.write('Some data added.')
