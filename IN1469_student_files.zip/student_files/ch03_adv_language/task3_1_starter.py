import logging
import sys

# Step 1. Import Enum and StringIO


from logging import Logger
from pathlib import Path

from multimethod import multimethod

logging.basicConfig(level=logging.INFO, format='--> %(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


# Step 2. Create an Enum called FlushStatus that has three states: FILE, LOG, and DISCARD.
#         Their values are up to you (can even be strings!).



# Step 3. Create the FlushStringIO class.  Have it inherit from StringIO.
#         Define an __init__() that takes a status (a FlushStatus type), *args, and **kwargs.
#         Within the __init__() call the base class __init__() pass the *args and **kwargs.
#         Finally, save the status on the self object.


# Step 4. Within the class, add three methods.  All of them should be called flush()
#         and all of them should be decorated with @multimethod.
#
#         The first accepts a string filename.  In the body of this method,
#         in a with control, open the file and write the StringIO contents out to the file.
#
#         The second method accepts a Logger object.  Call the info() method of the logger
#         within the method's body
#         The third method takes no params (except self).  Put a pass or ... within it.

# Step 5. Override the StringIO close() method by uncommenting the one shown below and
#         adjusting the indentation to place it in the class.
#
# def close(self):
#     print(f'Closing...status: {self.status.value}')
#     match self.status:
#         case FlushStatus.FILE:
#             self.flush('datafile.txt')
#         case FlushStatus.LOG:
#             self.flush(logging.getLogger())
#         case FlushStatus.DISCARD:
#             self.flush()
#
#     super().close()


if __name__ == '__main__':
    with FlushStringIO(status=FlushStatus.LOG) as fs:
        fs.write('Some data added.')

    try:
        fs.getvalue()                   # should be closed
    except ValueError as err:
        print('FlushStringIO is closed.')
