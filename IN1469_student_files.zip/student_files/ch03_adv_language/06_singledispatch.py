"""

    06_singledispatch.py

    While Python doesn't exactly support overloading, and this example might be better served using
    an abstract class that defines calc_pay(), here singledispatch is used to
    invoke the appropriately registered function based on the FIRST parameter passed in

"""

from functools import singledispatch


class Manager:
    def __init__(self, salary: float):
        self.salary = salary

    def calc_pay(self) -> float:
        return self.salary / 24


class HourlyEmployee:
    def __init__(self, rate: float):
        self.rate = rate

    def calc_pay(self, hours: float) -> float:
        return hours * self.rate


@singledispatch
def payment(employee: HourlyEmployee | Manager, amt: float = 0.0) -> float:
    raise NotImplementedError('You provided an object type that is not supported here.')


@payment.register
def _(employee: Manager) -> float:
    return employee.calc_pay()


@payment.register
def _(employee: HourlyEmployee, hours: float) -> float:
    return employee.calc_pay(hours)


m = Manager(salary=120_000)
h = HourlyEmployee(rate=48.00)
print(f'The manager gets: {payment(m)} this period.')
print(f'The employee gets: {payment(h, 33.0)} this period.')


# Uncomment below to generate a NotImplementedError
class Other:
    pass


# payment(Other())
