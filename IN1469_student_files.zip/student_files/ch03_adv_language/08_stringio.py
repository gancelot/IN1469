"""
    08_stringio.py
    StringIO objects provide a way to stage data in memory before using it elsewhere.
    They can perform better than strings when the strings get very long and have to be
    repeatedly modified.
"""
import io

buffer = io.StringIO()
buffer.write('This is the initial buffer value.\n')
print('Added to buffer.', file=buffer)
buffer_results = buffer.getvalue()
buffer.close()

print(buffer_results)

with io.StringIO() as buffer:
    buffer.write('A with version\n')
    print('closes automatically.', file=buffer)
    print(buffer.getvalue())
