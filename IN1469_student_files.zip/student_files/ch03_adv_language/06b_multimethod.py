"""

    06b_multimethod.py

    A modified version of the singledispatch using a third-party tool, called multimethod
    (note:multipledispatch is yet another tool that is very similar but not quite as good),
    that examines more than just the first parameter.  This version WILL consider the hours variable
    passed into the payment() method.  If it is not a float (try it with an int, for example)
    then the method fails not finding an appropriate implementation.


"""
from multimethod import multimethod


class Manager:
    def __init__(self, salary: float):
        self.salary = salary

    def calc_pay(self) -> float:
        return self.salary / 24


class HourlyEmployee:
    def __init__(self, rate: float):
        self.rate = rate

    def calc_pay(self, hours: float) -> float:
        return hours * self.rate


@multimethod
def payment(employee: Manager) -> float:
    return employee.calc_pay()


@multimethod
def payment(employee: HourlyEmployee, hours: float) -> float:
    return employee.calc_pay(hours)


m = Manager(salary=120_000)
h = HourlyEmployee(rate=48.00)
print(f'The manager gets: {payment(m)} this period.')
print(f'The employee gets: {payment(h, 33.0)} this period.')
