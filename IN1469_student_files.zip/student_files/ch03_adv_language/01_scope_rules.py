"""
        01_scope_rules.py

        The example shows how scope affects the visibility of various variables.
        What happens if you comment out the db_url = 'database3' statement?
        Is it different than what you expected?  Why?  Consider LEGB.
"""
db_url = 'database1'


class MovieStore:
    db_url = 'database2'

    def connect(self):
        db_url = 'database3'
        print(f'Connecting to: {db_url}')


ms = MovieStore()
ms.connect()
print(db_url)
