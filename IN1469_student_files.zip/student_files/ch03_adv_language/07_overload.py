"""

    07_overload.py
    How do we indicate with type hints that the get_location() function
    has two (and only two!) forms:
         get_location(str) -> list[str]
         get_location(Iterable[str]) -> list[list[str]]

    Answer: we can use @overload to indicate the acceptable forms
"""
from collections.abc import Iterable
from pathlib import Path
from typing import overload, Optional


with Path('../resources/airports.dat').open(encoding='utf-8') as f:
    f.readline()
    data = [line.strip().split(',')[1:9] for line in f]


@overload
def get_location(search: str) -> list[str]:
    ...


@overload
def get_location(search: Iterable[str]) -> list[list[str]]:
    ...


def get_location(search: str | Iterable[str]) -> list[str] | list[list[str]]:
    if isinstance(search, str):
        return [record[0].strip('"') for record in data if search.lower() in record[0].lower()]
    elif isinstance(search, Iterable):
        results = []
        for item in search:
            results.append([record[0].strip('"') for record in data if item.lower() in record[0].lower()])
        return results


print(get_location('Chicago'))
print(get_location(('London', 'Chicago')))


# ---------------------------------------------------
#           On a related note, if overloaded functions have a different number of parameters
#           when using @overload, it will be necessary to declare them as optional in the non-decorated
#           function, so they can be left out if needed. (see below)
@overload
def mult(a: int):
    ...


@overload
def mult(a: int, b: int):
    ...


def mult(a: int, b: Optional[int] = None):
    if b:
        return a*b
    else:
        return a*a


print(mult(3, 5))
print(mult(3))
