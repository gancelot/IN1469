"""

    03_position_keyword_only.py

    The following shows a function (get_location()) re-written several times using the
    positional-only (/) and keyword-only (*) syntax.

"""
import sys
from pathlib import Path

with Path('../resources/airports.dat').open(encoding='utf-8') as f:
    f.readline()
    data = [line.strip().split(',')[1:9] for line in f]


# ------------------------------------------------------------------------------------
# A standard function that can be called several ways
#
def get_location(search_name: str = None, max_results: int = 5) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location('chicago', 3)
print(results)
results = get_location('chicago', max_results=3)
print(results)
results = get_location(search_name='chicago', max_results=3)
print(results)
results = get_location(max_results=3, search_name='chicago')
print(results)


# ------------------------------------------------------------------------------------
# Now using the positional-only parameter IN THE MIDDLE causes the third call to fail!
#
def get_location(search_name: str = None, /, max_results: int = 5) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location('chicago', 3)
print(results)
results = get_location('chicago', max_results=3)
print(results)
try:
    results = get_location(search_name='chicago', max_results=3)
    print(results)
except TypeError as err:
    print(err, file=sys.stderr)


# ------------------------------------------------------------------------------------
# Now using the positional-only parameter AT THE END
#
def get_location(search_name: str = None, max_results: int = 5, /) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location('chicago', 3)
print(results)
try:
    results = get_location('chicago', max_results=3)
    print(results)
except TypeError as err:
    print(err, file=sys.stderr)


# ------------------------------------------------------------------------------------
# Now using the keyword-only parameter IN THE MIDDLE
def get_location(search_name: str = None, *, max_results: int = 5) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location('chicago', max_results=3)
print(results)
results = get_location(search_name='chicago', max_results=3)
print(results)
try:
    results = get_location('chicago', 3)
    print(results)
except TypeError as err:
    print(err, file=sys.stderr)


# ------------------------------------------------------------------------------------
# Now using the keyword-only parameter AT THE BEGINNING
def get_location(*, search_name: str = None, max_results: int = 5) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location(search_name='chicago', max_results=3)
print(results)
try:
    results = get_location('chicago', max_results=3)
    print(results)
except TypeError as err:
    print(err, file=sys.stderr)


# ------------------------------------------------------------------------------------
# Now using the BOTH positional AND keyword-only parameters
def get_location(search_name: str = None, /, *, max_results: int = 5) -> list[str]:
    if max_results < 1:
        max_results = len(data)
    return [record[0].strip('"') for record in data if search_name.lower() in record[0].lower()][:max_results]


results = get_location('chicago', max_results=3)
print(results)
try:
    results = get_location(search_name='chicago', max_results=3)
    print(results)
except TypeError as err:
    print(err, file=sys.stderr)
