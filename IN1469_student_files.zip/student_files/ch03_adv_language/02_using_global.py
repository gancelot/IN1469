"""
        02_using_global.py

        To modify a global variable inside of a function (any function), use the keyword: global.
"""
db_url = 'database1'


class MovieStore:
    db_url = 'database2'

    def connect(self):
        global db_url
        db_url = 'database3'
        print(f'Connecting to: {db_url}')


ms = MovieStore()
ms.connect()
print(db_url)
