"""
    task_3_1_solution_alt.py

    This version differs from the task in that it uses a Flag instead of an
    Enum so that operations can be combined such as FlushStatus.FILE | FlushStatus.LOG.
    The main change comes in how we evaluate the Flag, which occurs in the close() method.
"""
import logging
import sys
from enum import Flag, auto
from io import StringIO
from logging import Logger
from pathlib import Path

from multimethod import multimethod

logging.basicConfig(level=logging.INFO, format='--> %(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


class FlushStatus(Flag):
    FILE = auto()                # can also just use your own numbers such as 1, 2, 4
    LOG = auto()
    DISCARD = auto()


class FlushStringIO(StringIO):
    def __init__(self, status: FlushStatus, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.status = status

    @multimethod
    def flush(self, filename: str):
        with Path(filename).open(mode='wt', encoding='utf-8') as f:
            f.write(self.getvalue())

    @multimethod
    def flush(self, logger: Logger):
        logger.info(self.getvalue())

    @multimethod
    def flush(self):
        pass

    def close(self):
        print(f'Closing...status: {self.status.value}')
        if FlushStatus.FILE in self.status:
            self.flush('datafile.txt')
        if FlushStatus.LOG in self.status:
            self.flush(logging.getLogger())

        super().close()


if __name__ == '__main__':
    with FlushStringIO(status=FlushStatus.FILE | FlushStatus.LOG) as fs:
        fs.write('Some data added.')

    try:
        fs.getvalue()                               # error, should be closed
    except ValueError as err:
        print('FlushStringIO is closed.')
