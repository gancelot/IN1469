from django.urls import re_path

from racerapp import views

urlpatterns = [
    re_path(r'register/(?P<racename>[^/]+)', views.register, name='racerapp_register'),
    re_path(r'submit/', views.submit, name='racerapp_submit_reg'),
    re_path(r'participants/(?P<racename>[^/]+)', views.participants, name='racerapp_get_participants'),
    re_path(r'^$', views.list_races, name='race_list')
]
