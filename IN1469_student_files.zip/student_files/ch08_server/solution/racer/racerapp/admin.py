from django.contrib import admin

# Register your models here.
from racerapp.models import Race, Participant

admin.site.register(Race)
admin.site.register(Participant)
