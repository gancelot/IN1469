from django.shortcuts import render
from django.http import HttpResponse
from django.core import serializers

from racerapp.models import Race, Participant


def list_races(request):
    races = Race.objects.values()
    return render(request, 'list.html', {'races': races})
