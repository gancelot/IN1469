from django.urls import re_path

from racerapp import views

urlpatterns = [
    # more paths placed here in a moment
    re_path(r'^$', views.list_races, name='race_list')
]
