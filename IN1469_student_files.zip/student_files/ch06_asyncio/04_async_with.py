"""

    04_async_with.py

"""
import asyncio
from pathlib import Path

import aiofiles
from asyncstdlib import islice


async def process_data(filepath: Path):
    async with aiofiles.open(filepath) as f:
        async for line in islice(f, 10):
            print(f'{filepath.name}: {line.strip()}')


async def main(files: list[str]):
    async with asyncio.TaskGroup() as tg:
        for f in files:
            tg.create_task(process_data(Path(f'../resources/{f}')))


data_files = ['car_crashes.csv', 'accounts.csv', 'contacts.dat']
asyncio.run(main(data_files))
