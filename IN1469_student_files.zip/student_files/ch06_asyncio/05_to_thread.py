"""

    05_to_thread.py

"""
import asyncio


def nonblocking_func(val: int):
    for val1 in range(1, 300):
        if val1 % val == 0:
            print(f'{val1} / {val}')


async def main():
    await asyncio.gather(asyncio.to_thread(nonblocking_func, 3),
                         asyncio.to_thread(nonblocking_func, 5),
                         asyncio.to_thread(nonblocking_func, 7))


asyncio.run(main())
