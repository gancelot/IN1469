import asyncio

import requests
from bs4 import BeautifulSoup


# Step 1. Rename the function from get_data to async_get_data (this is not necessary, but
#         it will help us recognize the function as an asynchronous one.
#         Add the async keyword in front of the function.
def get_data(url: str) -> str:
    try:
        # Step 2. Wrap asyncio.to_thread() around requests.get.  Also pass in the url as a
        #         positional parameter.  Finally, add await in front of the asyncio.to_thread()
        #         call to indicate you wish this to be scheduled into the event loop.
        resp = requests.get(url)
        text = resp.text
        soup = BeautifulSoup(text, 'html.parser')
        result = soup.title.text
    except (TypeError, requests.exceptions.ConnectionError) as err:
        result = err.args[0]

    return result


tasks = ['https://requests.readthedocs.io/en/latest/', 'https://automatetheboringstuff.com', 'https://pypi.python.org',
         'https://realpython.com/', 'https://www.practicepython.org/', 'https://love-python.blogspot.com/',
         'https://planetpython.org/', 'https://www.python.org/doc/humor/', 'https://lucumr.pocoo.org/',
         'https://doughellmann.com/blog/', 'https://pymotw.com/3/', 'https://python-history.blogspot.com/',
         'https://nothingbutsnark.svbtle.com/', 'https://www.pydanny.com/', 'https://pythontips.com/',
         'https://www.blog.pythonlibrary.org/']


# Step 3. Create a main() function and mark it as async.  Within it, call gather() and pass
#         a list comprehension, or even better, pass a generator expression.
#         Don't forget to place an await keyword in front of the gather() call.
#         Within the generator expression iterate through the task grabbing one url and passing
#         it into the async_get_data() function call.
#         Save the results (return value) from gather()
#         Print the results out in a simple for-loop.



# Step 4. Call asyncio's run() method passing a main() call into it.

