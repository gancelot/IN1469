"""

    03_aiofiles.py  -   demonstrates the previous example but now uses
                        third-party asyncio libraries such as aiofiles and asyncstdlib

"""
import asyncio
from pathlib import Path

import aiofiles
from asyncstdlib import islice


async def process_data(filepath: Path):
    async with aiofiles.open(filepath) as f:
        async for line in islice(f, 10):
            print(f'{filepath.name}: {line.strip()}')


async def main(files: list[str]):
    files = (Path(f'../resources/{file_obj}') for file_obj in files)
    tasks = (process_data(f) for f in files)
    await asyncio.gather(*tasks)


data_files = ['car_crashes.csv', 'accounts.csv', 'contacts.dat']
asyncio.run(main(data_files))
