import logging
import sys
from typing import Any

import click
import colorama

# import mocklab                     # uncomment only if internet access is not available, otherwise leave commented out
from app import Store, MovieStore
from app import TMDBMovieQuery

logging.basicConfig(level=logging.INFO, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def persist(store: Store, persist_obj: Any) -> int:
    with store:
        obj_id = store.add(persist_obj)
        logging.info(f'Object saved with id: {obj_id}')

        # not needed, but just checking our get() method...
        obj = store.get(obj_id)
        logging.info(f'Found object in db: {obj}')

    return obj_id


query = TMDBMovieQuery()
search_val = click.prompt('Movie title search phrase', default='thor', show_default=True)
movie_list = query.search(search_val)

if movie_list:
    for idx, movie in enumerate(movie_list, 1):
        print(colorama.Fore.RED, f'{idx} - {movie.get('title', '(no title)')}')

    selected = click.prompt(text='Enter a number for details', default=1,
                            type=click.IntRange(1, len(movie_list), clamp=True))

    movie_id = movie_list[selected - 1].get('id')

    print(colorama.Fore.GREEN)
    m = query.get_movie(movie_id)
    logging.info(m.render())
    logging.info(f'Runtime: {len(m)}')
    print(colorama.Fore.BLACK)

    if click.confirm('Persist movie?'):
        persist(MovieStore(), m)
