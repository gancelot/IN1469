import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class StoreException(Exception):
    def __init__(self, message):
        super().__init__(message)


class Store(ABC):
    def __init__(self):
        try:
            self.conn = self.connect()
            logger.debug('Connection opened.')
        except Exception as err:
            raise StoreException('Error opening connection.') from err

    @abstractmethod
    def connect(self):
        pass

    @abstractmethod
    def add(self, model):
        pass

    @abstractmethod
    def get(self, id):
        pass

    def __enter__(self):
        return self

    def __exit__(self, typ, msg, tb):
        self.close()

    def close(self):
        if self.conn:
            try:
                self.conn.commit()
                logger.debug('Data committed.')
            except Exception as err:
                self.conn.rollback()
                logger.debug('Data rolled back.')
                raise StoreException('Error committing data.') from err
            finally:
                if self.conn:
                    self.conn.close()
                    logger.debug('Connection closed.')
                else:
                    raise StoreException('Connection failed to close.')
