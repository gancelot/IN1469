import logging
import sqlite3
from pathlib import Path

from .abstract import Store, StoreException
from ..movie import Movie

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class MovieStore(Store):
    db_url = Path(__file__).parents[4] / 'resources/course_data.db'
    logger.debug(f'Using db location: {db_url}')

    def connect(self):
        return sqlite3.connect(MovieStore.db_url)

    def add(self, movie: Movie) -> int:
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO movies (title, release_date, runtime, budget, revenue, tagline) VALUES(?, ?, ?, ?, ?, ?)',
                           (movie.title, movie.release_date, movie.runtime, movie.budget, movie.revenue, movie.tagline))
            row_id = cursor.lastrowid
            logger.debug(f'Insert with id: {row_id}')
        except Exception as err:
            raise StoreException('Error adding movie.') from err

        return row_id

    def get(self, movie_id) -> Movie:
        try:
            cursor = self.conn.cursor()
            sql = f'SELECT title, release_date, runtime, budget, revenue, tagline FROM movies WHERE id = ?'
            cursor.execute(sql, (movie_id,))
            results = cursor.fetchone()
            results_dict = {k:v for k, v in zip(Movie.model_fields, results)}
            logger.debug(f'Movie retrieved with values: {results_dict}')
        except Exception as err:
            raise StoreException('Error retrieving movie.') from err

        return Movie(**results_dict)
