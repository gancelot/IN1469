"""

    04_pydantic_json.py

    Pydantic supports nested structures and re-validation if desired.

"""
import json
import sys
from dataclasses import dataclass, asdict
from typing import Optional

from dataclasses_json import dataclass_json
from pydantic import BaseModel, ValidationError


class Distance(BaseModel, validate_assignment=True):
    amount: float = 0.0
    units: str = 'km'


class Race(BaseModel, validate_assignment=True):
    name: str = ''
    distance: Distance
    size: Optional[int] = 0


json_data = '''
{
    "name": "BolderBoulder",
    "distance": {
        "amount": 6.14, 
        "units": "mi"
    }
}
'''

results = json.loads(json_data)
race = Race(**results)
print(race)                         # Works!
print(race.model_dump_json())       # Pydantic's way of JSON serialization
try:
    race.distance = -5              # Pydantic will re-validate this if validate_assignment is True
except ValidationError as err:
    print(err.json(), file=sys.stderr)


# -------------------------------------------------------------------------
# Use of nested Dataclasses (like Pydantic version above, but now dataclasses)...
#
#
@dataclass_json
@dataclass
class Distance:
    amount: float = 0.0
    units: str = 'km'


@dataclass_json
@dataclass
class Race:
    name: str = ''
    distance: Distance = None


r = Race(10, Distance(6.219, 'mi'))
print(vars(r))
print(asdict(r))                         # <-- better than vars()
print(json.dumps(asdict(r)))
print(r.to_json())
