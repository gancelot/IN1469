import logging
import sys
from typing import Any

import click
import colorama

# import mocklab                     # uncomment only if internet access is not available, otherwise leave commented out

# Step 4a. Import the Store and MovieStore from the flushstringio level

from app import TMDBMovieQuery

logging.basicConfig(level=logging.INFO, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


# Step 4b. Complete the persist() method below.
#          This method should pass in a generic (abstract) Store object and the object to be persisted
def persist():
    pass
    # Step 4c. Remove the pass statement above.
    #          Place the store in a with control.  In the with, call add() passing the object to be persisted.
    #          In the same with statement, call the store's get() method passing the id returned from the add()
    #          call (this is mostly just to test it out).  Return the id from the add() call.


query = TMDBMovieQuery()
search_val = click.prompt('Movie title search phrase', default='thor', show_default=True)
movie_list = query.search(search_val)

if movie_list:
    for idx, movie in enumerate(movie_list, 1):
        print(colorama.Fore.RED, f'{idx} - {movie.get('title', '(no title)')}')

    selected = click.prompt(text='Enter a number for details', default=1,
                            type=click.IntRange(1, len(movie_list), clamp=True))

    movie_id = movie_list[selected - 1].get('id')

    print(colorama.Fore.GREEN)
    m = query.get_movie(movie_id)
    logging.info(m.render())
    logging.info(f'Runtime: {len(m)}')
    print(colorama.Fore.BLACK)

    # Step 5. Invoke click.confirm() in an if-statement.
    #         If the user types 'y' or 'yes' the if-statement evaluates to True.  Call
    #         the persist() method from step 4 passing in a new MovieStore instance and the
    #         movie object that will be persisted.

