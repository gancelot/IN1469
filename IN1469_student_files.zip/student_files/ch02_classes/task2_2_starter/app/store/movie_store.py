import logging
import sqlite3
from pathlib import Path

from .abstract import Store, StoreException
from ..movie import Movie

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

# Step 2a. Inherit from the base class Store (already imported).
class MovieStore:
    db_url = Path(__file__).parents[4] / 'resources/course_data.db'
    logger.debug(f'Using db location: {db_url}')

    # Step 2b. Implement the connect method (it takes no args except self).
    #          It will have one line:    return sqlite3.connect()
    #          Pass the db_url variable above into the call.


    # Step 2c. Implement the add() abstract method from the base class passing in a movie object.  You can change the
    #          type passed in from the parent's object type--specifically to a Movie type.
    #          It returns an int (the id of the row inserted).
    #          In the body of the method, implement the following provided code:

    #    try:
    #        cursor = self.conn.cursor()
    #        cursor.execute('INSERT INTO movies (title, release_date, runtime, budget, revenue, tagline) VALUES(?, ?, ?, ?, ?, ?)',
    #                       (movie.title, movie.release_date, movie.runtime, movie.budget, movie.revenue, movie.tagline))
    #        row_id = cursor.lastrowid
    #        logger.debug(f'Insert with id: {row_id}')
    #    except Exception as err:
    #        raise StoreException('Error adding movie.') from err
    #
    #    return row_id


    # Step 2d. Implement the get() method defined in the parent abstract class.  You can change
    #          the generic id to a specific name such as movie_id.  The method returns a Movie object type.
    #          In the body of the method, implement the following provided code:

    #    try:
    #        cursor = self.conn.cursor()
    #        sql = f'SELECT title, release_date, runtime, budget, revenue, tagline FROM movies WHERE id = ?'
    #        cursor.execute(sql, (movie_id,))
    #        results = cursor.fetchone()
    #        results_dict = {k:v for k, v in zip(Movie.model_fields, results)}     # converts results tuple into a dict
    #        logger.debug(f'Movie retrieved with values: {results_dict}')
    #    except Exception as err:
    #        raise StoreException('Error retrieving movie.') from err
    #
    #    return Movie(**results_dict)
