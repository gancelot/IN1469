import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class StoreException(Exception):
    def __init__(self, message):
        super().__init__(message)


# Step 1a. Make the store an abstract class.
class Store:
    def __init__(self):
        try:
            self.conn = self.connect()
            logger.debug('Connection opened.')
        except Exception as err:
            raise StoreException('Error opening connection.') from err

    # Step 1b. Add the 3 methods (defined in our slide).  Make them all abstract.
    #          Simply put "pass" in the body of each
    #          Don't be concerned with annotations here (yet).


    def __enter__(self):
        return self

    def __exit__(self, typ, msg, tb):
        self.close()

    def close(self):
        if self.conn:
            try:
                self.conn.commit()
                logger.debug('Data committed.')
            except Exception as err:
                self.conn.rollback()
                logger.debug('Data rolled back.')
                raise StoreException('Error committing data.') from err
            finally:
                if self.conn:
                    self.conn.close()
                    logger.debug('Connection closed.')
                else:
                    raise StoreException('Connection failed to close.')
