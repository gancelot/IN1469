"""

    02_properties.py - illustrating the use of properties via the distance attribute

"""


class Race:

    def __init__(self, name: str = '', distance: float = 0.0, units: str = 'km'):
        self.name = name
        self.distance = distance
        self.units = units

    @property
    def distance(self) -> float:
        return self._distance

    @distance.setter
    def distance(self, distance: float) -> None:
        if distance < 0:
            distance = 0.0
        self._distance = distance

    def __str__(self):
        return f'{self.name} ({self.distance} {self.units})'

    def __repr__(self):
        return f'({self.name}) {type(self)}'


race1 = Race('BOLDERBoulder', -10, 'km')
print(race1)
