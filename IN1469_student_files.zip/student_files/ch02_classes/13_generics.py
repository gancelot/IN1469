"""

    13_generics.py      -   Example showing how Python supports the concept of Generics

"""
from dataclasses import dataclass
from typing import Generic, TypeVar

from dataclasses_json import dataclass_json

T = TypeVar('T')


@dataclass_json
@dataclass
class Race:
    name: str = ''
    distance: float = 0.0
    units: str = 'km'


race1 = Race('BOLDERBOULDER', 6.214, 'mi')


class GenericListing(Generic[T]):
    items: dict[str, T] = {}

    def add(self, key: str, item: T) -> None:
        self.items[key] = item
        print(f'{type(item).__name__} added.')

    def get(self, key: str) -> T:
        return self.items.get(key)


class RaceList(GenericListing[Race]):
    pass


rlist = GenericListing[Race]()
rlist.add('BOLDERBoulder', race1)
rlist.add('Unknown', 10)                                        # still gets added at runtime.

rlist2 = RaceList()
rlist2.add('Peachtree', Race('Peachtree', 'Georgia'))
rlist2.add('Unknown', 10)
