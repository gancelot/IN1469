import logging
import sys

import click
import colorama

# import mocklab                     # uncomment only if internet access is not available, otherwise leave commented out
# Step 9. Import the TMDBMovieQuery class from the shortcut location


logging.basicConfig(level=logging.INFO, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

# Step 10. Instantiate the TMDBMovieQuery class imported in the previous step.
#          Using the click library, prompt the user for a movie search prhase:
#          Example: search_val = click.prompt('Search phrase', default='thor', show_default=True)
#          Finally, pass the search phrase into the search() method of the TMDBMovieQuery object
#          Get a list of results


# Step 11. Take the return value from the previous step and display it (this will be a list of
#          movies).  Enumerate the results (as shown on our task slide) such that they start at 1.
#          The syntax for using enumerate is:   for i, obj in enumerate(iterable, start_num)
#
#          The use of colorama is optional, but its syntax is:  print(colorama.Fore.RED, f'<your string>')


# Step 12. Using the previous output, prompt the user to select an item from the list of movies.
#          The click library can prevent the user from entering invalid values.  Try it with this
#          syntax:
#                   click.prompt(text='Enter a number for details', default=1,
#                                type=click.IntRange(1, len(movie_list), clamp=True))
#
#          Take the number provided by the user, plug it into our movie_list (from step 10).
#          You may need to subtract one since the output numbered starting at 1 and the list
#          starts numbering at 0.
#          The object you get from this is a dict, use .get('id') to extract the movie's id.
#          (step 13 is in query.py)


# Step 14.  Invoke the get_movie() function of the TMDBMovieQuery object.  Pass in the movie_id.
#           Using the returned movie object, print (or info() log) the render() method of the movie.
#           Optionally use a green colorama color.


# Step 15.  For fun, test the __len__() magic method created earlier by passing the movie object
#           into a len() call.  That's it test it all out.
