# Step 5. Add a shortcut import here for the Movie class

# Step 8. Add a shortcut import here for the TMDBMovieQuery class

