import logging
import requests

# Step 6. Import the Movie class from the shortcut


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class TMDBMovieQuery:
    key = '23cf8b21d9a3bfd615076491d6bae442'
    search_url = 'https://api.themoviedb.org/3/search/movie?api_key={key}&query={title}'
    details_url = 'https://api.themoviedb.org/3/movie/{id}?api_key={key}'

    # Step 7. Create the search() function.  In addition to self, it also accepts a search_term.
    #         a) Have it make a request to our search_url using requests.get().
    #         b) Use .format() to insert the provided key into the key param in the string
    #            and the search_term into the title param of the string.
    #         c) Convert the results into a dictionary using the .json() method from requests.
    #         d) Save this value in the search_dict variable.
    #         e) Add the following exception handling around the requests.get() call:
    #             try:
    #
    #             except: requests.RequestException as rex:
    #                  logger.error(f'Request excpetion occurred: {rex.args}')
    #         f) The function should extract and return the list from the 'results' key of the search_dict
    #         g) Optionally, add in type hints.  search_term is a str and the function returns a list of dicts.


    # Step 13.  Complete this class by adding a get_movie() method.  It should accept a movie_id (str).
    #           a) Within the method, make a request (use requests.get()) using the details_url.
    #           Refer to how you did it above in the search() method.
    #           b) Use .format() to insert the needed missing values into the details_url.
    #           c) After the request is complete, perform a .json() to convert the results to a dict.
    #           d) Pass the dict into a new Movie() instance (hint: use ** on the dict)
    #           e) Return the movie from the method
    #           Optionally, add in type hints.  The movie_id is a string and the method returns a Movie
    #           f) Add exception handling around your requests.get() and new movie instantiation:
    #                 try:
    #
    #                 except RequestException as rex:
    #                     logger.error(f'Request exception occurred: {rex.args}')


