import logging
from pathlib import Path

import jinja2
from pydantic import BaseModel

tmpl_location = Path(__file__).parent / 'tmpl'
env = jinja2.Environment(loader=jinja2.FileSystemLoader(tmpl_location))

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


# Step 1. Create a class called Movie that inherits from BaseModel (already imported).
#         This will be a Pedantic Model therefore the fields should be placed in the
#         class but not within an __init__().  Add a title (str), release_date (str),
#         runtime (int), budget (int), revenue (int), and tagline (str) attribute.  Add appropriate
#         default values for each attribute.


# Step 2. Create a method within the class called render() that accepts
#         no additional arguments (except self).
#         Indicate, using a type hint, that the function returns a string.
#         Add. the provided Jinja2 template code below into the method.
#
#         try:
#             tmpl = env.get_template('movie.jinja')
#             results = tmpl.render(movie=self)
#         except jinja2.exceptions.TemplateError as err:
#             logger.error(f'{type(err)}: {err}')
#             results = f'Error rendering movie.  See error-level log.'
#         return results

# Step 3. Implement the __len__() magic method within the class to return the runtime of the movie.
#         Note: __len__() takes no arguments (except self).

#     Optionally, you may add this __str__() magic method use only for testing below.
#     def __str__(self):
#         return f'{self.title} [${self.revenue:,}]'


# Step 4. Test out the solution by creating a conditional block that only executes
#         when the module is run directly.
#           Hint: if __name__ == '__main__':
#         Within the block, instantiate a Movie
#         and expand data into it (hint: use **data).
#         data = {'title': 'Avengers'}
#         Invoke the render() function and print its results.
#         Optionally, print the movie object itself by passing it into print() directly.
