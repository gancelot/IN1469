"""

    08_descriptors_again.py     -   a second example of using descriptors

    This descriptor moves the behavior of converting data values into 'mi' units into another
    class called Convert.

"""
from weakref import WeakKeyDictionary


class Convert:
    conversions = {'mi': 1.0, 'km': 0.621, 'm': 0.000621, 'ft': 0.0001894}

    def __init__(self):
        self.data = WeakKeyDictionary()

    def __get__(self, instance, owner):
        return self.data.get(instance, 0)

    def __set__(self, instance, value):
        convert_value = self.conversions.get(instance.units.lower(), 0)
        self.data[instance] = value * convert_value
        instance.units = 'mi'


class Race:
    distance = Convert()

    def __init__(self, name: str = '', distance: float = 0.0, units: str = 'mi'):
        self.name = name
        self.units = units
        self.distance = distance

    def __str__(self):
        return f'{self.name}: {self.distance:.1f} {self.units}'


race1 = Race('BolderBOULDER', 10, 'km')
print(race1)

race2 = Race('Hot Chocolate 5k', 16404, 'ft')
print(race2)

race3 = Race('Alien Sprint', 100, 'blips')
print(race3)
