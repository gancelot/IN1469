"""

    09_jinja2.py        -       shows how to use the Jinja2 framework in a simple use case

"""
import sys

from jinja2 import Environment, FileSystemLoader
from jinja2.exceptions import TemplateError
env = Environment(loader=FileSystemLoader('./tmpl'))


class Race:
    def __init__(self, name='', distance=0.0, units='km'):
        self.name = name
        self.units = units
        self.distance = distance

    def __str__(self):
        return f'{self.name} ({self.distance} {self.units})'


races = [
    Race('BolderBOULDER', 10000, 'm'),
    Race('Chicago Marathon', 26.2, 'mi'),
    Race('Carlsbad 5000', 5, 'km'),
    Race('Country Music Half Marathon', 13.1, 'mi'),
    Race('Capitol Mile', 5280, 'ft'),
    Race('Peachtree Road Race', 10, 'km'),
]

try:
    tmpl = env.get_template('example_tmpl.jinja')
    print(tmpl.render(data=races))
except TemplateError as err:
    print(f'Error: {type(err)} {err}', file=sys.stderr)
