import logging
import sys

import click
import colorama

# import mocklab                     # uncomment only if internet access is not available, otherwise leave commented out
from movie import TMDBMovieQuery

logging.basicConfig(level=logging.INFO, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


query = TMDBMovieQuery()
search_val = click.prompt('Movie title search phrase', default='thor', show_default=True)
movie_list = query.search(search_val)

if movie_list:
    for idx, movie in enumerate(movie_list, 1):
        print(colorama.Fore.RED, f'{idx} - {movie.get('title', '(no title)')}')

    selected = click.prompt(text='Enter a number for details', default=1,
                            type=click.IntRange(1, len(movie_list), clamp=True))

    movie_id = movie_list[selected - 1].get('id')

    print(colorama.Fore.GREEN)
    m = query.get_movie(movie_id)
    logging.info(m.render())
    logging.info(f'Runtime: {len(m)}')
