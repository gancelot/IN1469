import logging
from pathlib import Path

import jinja2
from pydantic import BaseModel

tmpl_location = Path(__file__).parent / 'tmpl'
env = jinja2.Environment(loader=jinja2.FileSystemLoader(tmpl_location))

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class Movie(BaseModel):
    title: str = '(no title)'
    release_date: str = ''
    runtime: int = 0
    budget: int = 0
    revenue: int = 0
    tagline: str = ''

    def render(self) -> str:
        try:
            tmpl = env.get_template('movie.jinja')
            results = tmpl.render(movie=self)
        except jinja2.exceptions.TemplateError as err:
            logger.error(f'{type(err)}: {err}')
            results = f'Error rendering movie.  See error-level log.'
        return results

    def __len__(self):
        return self.runtime

    def __str__(self):
        return f'{self.title} [${self.revenue:,}]'


if __name__ == '__main__':
    data = {'title': 'Avengers'}
    m = Movie(**data)
    print(f'Movie: {m}')
    print(m.render())

# What happens if a data value is not a correct type...
#     data = {'title': 'Avengers', 'revenue': 'hello'}
#     m = Movie(**data)
#     print(m.render())
