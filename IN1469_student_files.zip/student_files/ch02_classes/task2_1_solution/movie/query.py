import logging

import requests

from . import Movie

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class TMDBMovieQuery:
    key = '23cf8b21d9a3bfd615076491d6bae442'
    search_url = 'https://api.themoviedb.org/3/search/movie?api_key={key}&query={title}'
    details_url = 'https://api.themoviedb.org/3/movie/{id}?api_key={key}'

    def search(self, search_term: str) -> list[dict[str, str]]:
        search_dict = {}
        try:
            search_dict = requests.get(self.search_url.format(key=self.key, title=search_term)).json()
        except requests.RequestException as rex:
            logger.error(f'Request exception occurred: {rex.args}')

        return search_dict.get('results', [])

    def get_movie(self, movie_id: str) -> Movie:
        m = Movie()
        try:
            details = requests.get(self.details_url.format(key=self.key, id=movie_id)).json()
            m = Movie(**details)
        except requests.RequestException as rex:
            logger.error(f'Request exception occurred: {rex.args}')
        return m
