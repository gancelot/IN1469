"""

    01_classes.py

    All the following calls would be valid here:
    Race()                                                              (void arguments)
    Race('NYC Marathon', 26.2, 'mi')                                    (passing positional arguments)
    Race('NYC Marathon', units='mi', distance=26.2)                     (passing keywords arguments
    Race(**{'name': 'NYC Marathon','distance': 10, 'units': 'km'})      (unpacking a dictionary)
    Race(*['NYC Marathon', 26.2, 'km'])                                 (unpacking an iterable)

"""


class Race:
    def __init__(self, name: str = '', distance: float = 0.0, units: str = 'km'):
        self.name = name
        self.distance = distance
        self.units = units

    def __str__(self):
        return f'{self.name} ({self.distance} {self.units})'

    def __repr__(self):
        return f'{type(self).__name__}({self.name})'

    def __getitem__(self, key):
        return self.__dict__.get(key)

    def __iter__(self):
        return iter(self.__dict__.items())

    def __eq__(self, other):
        if type(other) is not type(self):
            return False
        return True if self.distance == other.distance and self.units == other.units else False


race1 = Race('BOLDERBoulder', 10, 'km')                                              # __init__() called
race2 = Race(name='Chicago Marathon', distance=26.2, units='mi')                     # __init__() called
print(race1)                                                                         # __str__() called
print([race1, race2])                                                                # __str__() of [] calls __repr__()
print(race1['distance'])                                                             # __getitem__() called
print(*race1)                                                                        # __iter__() called
for item in race1:                                                                   # __iter__() called
    print(item)
print(Race('Peachtree', 10, 'km') == race1)                                          # __eq__() called
