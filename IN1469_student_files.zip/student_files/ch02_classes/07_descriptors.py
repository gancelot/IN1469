"""

    07_descriptors.py   -   A simple FullName descriptor

    Descriptors offload behavior to another class, keeping the original class short, simple, and
    easy to maintain.

"""


class FullName:
    def __get__(self, instance, owner):
        return ' '.join([instance.first, instance.last])

    def __set__(self, instance, new_name):
        names = new_name.split(' ')
        (first, last) = (names[0], ' '.join(names[1:])) if len(names) >= 2 else ('', new_name)
        instance.first = first
        instance.last = last


class Person:

    full_name: FullName = FullName()

    def __init__(self, first: str = '', last: str = ''):
        self.first = first
        self.last = last


p1 = Person('John', 'Smith')
print(p1.full_name)

p2 = Person('Sally', 'Jones')
p2.full_name = 'Sally Van Wilder'
print(p2.full_name)
