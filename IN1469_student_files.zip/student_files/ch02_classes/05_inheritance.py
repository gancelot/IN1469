"""

    05_inheritance.py


"""
from datetime import date


class Event:
    def __init__(self, name: str, location: str = '', event_date: date = None):
        self.name = name
        self.location = location
        self.event_date = event_date

    def __str__(self):
        return f'{self.name} ({self.event_date.strftime('%Y-%b-%d')})'

    __repr__ = __str__


class Race(Event):
    def __init__(self, name: str, location: str = '', event_date: date = None, distance: float = 0.0, units: str = 'km'):
        Event.__init__(self, name, location, event_date)
        self.distance = distance
        self.units = units

    def __str__(self):
        return f'Race: {Event.__str__(self)}'


events = [Event('Citywide Garage Sale', event_date=date(2024, 4, 14)),
          Race('BolderBOULDER', 'Boulder, CO', date(2024, 5, 27), 10, 'km'),
          Event('Presidential Election', 'USA', date(2024, 11, 5))]

print(events)
