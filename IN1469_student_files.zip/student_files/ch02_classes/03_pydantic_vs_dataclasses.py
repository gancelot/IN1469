"""

    03_pydantic_vs_dataclasses.py

    Pydantic:
        Pros: Good for variations/custom use cases in data validation, good for validation before database operations
        Cons: Can be slow if not careful, be sure to use Pydantic 2+.  Consider performance vs
              type safety as the main considerations here.

    Dataclasses:
        Pros: Simple and native to standard library, no extra tools to install
        Cons: Doesn't reach as far as Pydantic for the numerous config options Pydantic supports

"""
import sys
from dataclasses import dataclass

from dataclasses_json import dataclass_json
from pydantic import BaseModel, ValidationError, field_validator


@dataclass_json
@dataclass
class Race:
    name: str = ''
    _distance: float = 0.0
    units: str = 'km'

    def __post_init__(self):
        if self.units == 'mi':
            self.units = 'km'
            self.distance = self.distance * 1.60934

    @property
    def distance(self) -> float:
        return self._distance

    @distance.setter
    def distance(self, distance: float):
        if distance < 0:
            distance = 0.0
        self._distance = distance


race1 = Race('BOLDERBoulder', 6.214, 'mi')
print(race1)
print(race1.to_json())


# -----------------------------------------
# Pydantic version
# Simple Pydantic model field validation generates 2 validation errors: distance (can't be converted to float)
#                                                                       units (are required)
class Race(BaseModel):
    name: str
    distance: float
    units: str


try:
    race2 = Race(name='BOLDERBoulder', distance='five')
    print(race2)
except ValidationError as err:
    print(err, file=sys.stderr)


# -----------------------------------------
# Pydantic version
# Adding custom validations, the value provided is not a legal distance value
class Race(BaseModel):
    name: str = ''
    distance: float = 0.0
    units: str = 'km'

    @field_validator('distance')
    @classmethod
    def validate_distance(cls, distance):
        if distance < 0:
            raise ValueError('Invalid distance.')
        return distance


try:
    race3 = Race(name='BOLDERBoulder', distance=-5)
    print(race3)
except ValidationError as err:
    print(err, file=sys.stderr)

race4 = Race(name='BOLDERBoulder', distance=10)
print(race4)
race4.distance = -20

