"""

    10_abstract_classes.py      -   Uses abstract classes to guide behavior in children classes

"""
import abc
import sys


class AbstractBase(abc.ABC):
    def __init__(self, item):
        self.item = item
        self.do_action()

    @abc.abstractmethod
    def do_action(self):                # subclass will define this work
        pass                            # or raise NotImplementedError() or put actual code in here


class Concrete(AbstractBase):
    def do_action(self):
        print('in concrete do_action()')
        super().do_action()             # Concrete class can invoke abstract method of parent, if desired


c = Concrete('item')


# ----------------------------------------------------
# Second example with Abstract Classes
#
class TextMessage(abc.ABC):
    def __init__(self, msg):
        self.msg = msg

    @abc.abstractmethod
    def get_text(self):
        pass


class JsonMessage(TextMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def get_text(self) -> str:
        return f'{{ "text": "{self.msg}" }}'


class HtmlMessage(TextMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def get_text(self) -> str:
        return f'<span>{self.msg}</span>'


def show_message(msg: TextMessage) -> None:
    print(msg.get_text())


value = 'Meeting today at 3pm.'
show_message(HtmlMessage(value))
show_message(JsonMessage(value))

try:
    show_message(TextMessage('No Meeting today.'))
except TypeError as err:
    print(err, file=sys.stderr)
