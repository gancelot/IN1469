import tkinter as tk

window = tk.Tk()

label = tk.Label(text='Hello World',
                 foreground='#223344',
                 background='#fcfeee')
label.pack()

window.mainloop()
