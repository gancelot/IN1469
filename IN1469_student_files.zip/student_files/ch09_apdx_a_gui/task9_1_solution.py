import sys
import tkinter as tk

from webster import Webster


try:
    webster = Webster.read_data()
except Exception:
    print('Unable to load dictionary data. {err}', file=sys.stderr)
    sys.exit()


def get_selection():
    idx = word_list.curselection()                  # index of current selection as a tuple
    if idx:
        idx = idx[0]                                # the actual index value
        word = word_list.get(idx)                   # pull out the word to be defined
        definition.configure(text=webster[word])    # look up the word and set it in the bottom label


root = tk.Tk()
root.title('Webster App')
root.geometry('500x300')

word_frame = tk.Frame(master=root, padx=10, pady=10)
word_frame.pack(side='top', anchor='w')

word_list = tk.Listbox(master=word_frame, width=50)
for idx, item in enumerate(webster.keys()):
    word_list.insert(idx, item)
word_list.pack(side='left', fill='both')

scrollbar = tk.Scrollbar(master=word_frame)
scrollbar.pack(side='right', fill='both')
word_list.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=word_list.yview)

definition_frame = tk.LabelFrame(master=root, height=200, borderwidth=1, text='Definition')
definition_frame.pack(side='bottom', fill='x')

definition = tk.Label(master=definition_frame, wraplength=470, justify='left')
definition.pack(expand=True, padx=5, pady=5, side='left', fill='both')

button = tk.Button(text='Define', command=get_selection)
button.pack(side='bottom')

root.mainloop()
