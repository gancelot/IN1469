import tkinter as tk

root = tk.Tk()
root.title('pack() Layout')
root.geometry('400x300')

frame1 = tk.Frame(height=100, bg='#a00000')
frame1.pack(fill='x', side='top')

frame2 = tk.Frame(height=100, bg='#0000a0')
frame2.pack(fill='x', side='bottom')

frame3 = tk.Frame(bg='#009300')
frame3.pack(expand=True, side='left', fill='both')

frame4 = tk.Frame(bg='#00c600')
frame4.pack(expand=True, side='left', fill='both')

frame5 = tk.Frame(bg='#00e900')
frame5.pack(expand=True, side='left', fill='both')

root.mainloop()
