import tkinter as tk


def copy_text():
    label.configure(text=entry.get())


root = tk.Tk()
root.geometry('550x100')

entry = tk.Entry(width=16, font=16)
entry.place(x=10, y=15)

button = tk.Button(text='Copy Text', font=16, width=10, command=copy_text)
button.place(x=220, y=10)

label = tk.Label(text='', font=16, width=16, fg='#4444ff')
label.place(x=340, y=15)


root.mainloop()
