import sys
import tkinter as tk

from webster import Webster


try:
    webster = Webster.read_data()                                   # read our data into a dict
except Exception:
    print('Unable to load dictionary data. {err}', file=sys.stderr)
    sys.exit()


# Step 6. Complete the Button press command= event handler below.  Follow the instructions
#         in the workbook.
def get_selection():
    pass


root = tk.Tk()
root.title('Webster App')
root.geometry('500x300')

# Step 1. Create the Frame that will hold the Listbox and Scrollbar
#         Set the master=root and use padx=10 and pady=10
#         Use the pack() layout with side='top' and anchor='w'


# Step 2. Within the Frame we'll add a Listbox.  Instantiate a Listbox and
#         attach it to the word_frame.  Let's limit its width to 50.
#         The code near the top loads our words up into a Python dict, so we can
#         build up the list box by iterating over the words and inserting them into
#         the listbox.  Do this here (according to the instructions in the workbook).


# Step 3. A Scrollbar widget must be attached to the listbox (it's not automatic).
#         We'll then make it so the word_list scrolls based on the actions of the scrollbar.
#         Do this by adding the lines shown in the workbook for step 3.


# Step 4. Let's create a LabelFrame to help position a Label.  Then we'll create the Label()
#         widget to place inside it.  Do this according to step 4 in the workbook.


# Step 5. Let's add a Button to our UI and attach it to the bottom (although it will
#         physically appear above the LabelFrame because the LabelFrame was already
#         attached to the bottom.  Do this according to step 5 in the workbook.


root.mainloop()
