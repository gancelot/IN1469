import sys
import tkinter as tk

from ch09_apdx_a_gui.webster import Webster


class WordFrame(tk.Frame):
    def __init__(self, parent, data):
        super().__init__(master=parent, padx=10, pady=10)
        self.pack(side='top', anchor='w')

        self.word_list = tk.Listbox(master=self, width=50)

        for idx, item in enumerate(data.keys()):
            self.word_list.insert(idx, item)

        self.word_list.pack(side='left', fill='both')

        self.scrollbar = tk.Scrollbar(master=self)
        self.scrollbar.pack(side='right', fill='both')
        self.word_list.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.word_list.yview)


class DefinitionFrame(tk.LabelFrame):
    def __init__(self, parent):
        super().__init__(master=parent, height=200, borderwidth=1, text='Definition')
        self.pack(side='bottom', fill='x')

        self.definition = tk.Label(master=self, wraplength=470, justify='left')
        self.definition.pack(expand=True, padx=5, pady=5, side='left', fill='both')


class WebsterApp:
    def __init__(self, parent):
        parent.title('Webster App')
        parent.geometry('500x300')

        self.webster = self.load_data()

        self.word_frame = WordFrame(parent, self.webster)
        self.definition_frame = DefinitionFrame(parent)
        self.button = tk.Button(text='Define', command=self.get_selection)
        self.button.pack(side='bottom')

    def load_data(self):
        try:
            return Webster.read_data()
        except Exception:
            print('Unable to load dictionary data. {err}', file=sys.stderr)
            sys.exit()

    def get_selection(self):
        idx = self.word_frame.word_list.curselection()  # index of current selection as a tuple
        if idx:
            idx = idx[0]  # the actual index value
            word = self.word_frame.word_list.get(idx)  # pull out the word to be defined
            self.definition_frame.definition.configure(text=self.webster[word])  # look up the word and set it in the bottom label


root = tk.Tk()
WebsterApp(root)
root.mainloop()
