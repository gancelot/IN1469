import tkinter as tk


def copy_text():
    label.configure(text=entry.get())


window = tk.Tk()

entry = tk.Entry(font=16)
entry.pack(fill='x')

button = tk.Button(text='Copy Text', font=16, command=copy_text)
button.pack(fill='x')

label = tk.Label(text='', font=16)
label.pack(fill='x')



window.mainloop()
