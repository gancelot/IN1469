import tkinter as tk

window = tk.Tk()
window.mainloop()
