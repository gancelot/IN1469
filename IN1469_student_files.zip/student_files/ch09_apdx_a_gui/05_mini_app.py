import tkinter as tk

root = tk.Tk()
root.title('Temperature Conversion App')
root.geometry('500x120')


def enter_key(event):
    if event.keycode == 13:
        convert()


def convert():
    try:
        value = int(entry.get())
        conversion = 5.0 * (value - 32.0) / 9.0
        lbl_output.configure(text=str(conversion))
    except ValueError:
        lbl_output.configure(text='Must be a number!')


# row 0 definitions
lbl_fahr = tk.Label(font=16, fg='blue', text='Fahrenheit')
lbl_fahr.grid(row=0, column=0, ipadx=2, ipady=2, sticky='W')

lbl_celcius = tk.Label(font=16, fg='blue', text='Celcius')
lbl_celcius.grid(row=0, column=2, ipadx=2, ipady=2, sticky='W')

# row 1 definitions
entry = tk.Entry(font=16)
entry.configure(text='0')
entry.grid(row=1, column=0, ipadx=2, ipady=2)

button = tk.Button(font=16, text='>>>', command=convert)
button.grid(row=1, column=1, ipadx=2, ipady=2)

lbl_output = tk.Label(master=root, font=16, text='0',
                      foreground='#223344', background='#fcfeee')
lbl_output.grid(row=1, column=2, ipadx=2, ipady=2)


root.bind('<Key>', enter_key)
root.mainloop()
