import tkinter as tk

root = tk.Tk()
root.title('pack() Layout')
root.geometry('400x300')

frame1 = tk.Frame(width=100, height=100, bg='#a00000')
frame1.pack()

frame2 = tk.Frame(width=100, height=100, bg='#00a000')
frame2.pack()

frame3 = tk.Frame(width=100, height=100, bg='#0000a0')
frame3.pack()

root.mainloop()
