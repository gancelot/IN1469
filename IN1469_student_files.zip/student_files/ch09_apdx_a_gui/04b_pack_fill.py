import tkinter as tk

root = tk.Tk()
root.title('pack() Layout')
root.geometry('400x300')

frame1 = tk.Frame(height=100, bg='#a00000')
frame1.pack(fill='x')

frame2 = tk.Frame(width=100, height=100, bg='#00a000')
frame2.pack(side='right')

frame3 = tk.Frame(height=50, bg='#0000a0')
frame3.pack(padx=30, fill='x', side='bottom')

root.mainloop()
