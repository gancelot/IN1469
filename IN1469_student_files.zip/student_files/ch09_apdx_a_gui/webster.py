from importlib.resources import open_text
import sys


class Webster:
    @staticmethod
    def read_data(package: str = 'resources', filename: str = 'dictionary.txt'):
        """
        :param package: (str) directory within the sys.path containing our desired file
        :param filename: (str) our data file
        :return: (dict) dictionary where keys are the words and values are the definitions
        """
        results = {}
        try:
            with open_text(package, filename, encoding='utf-8-sig') as f:
                for line in f:
                    try:
                        word, definition = line.split(maxsplit=1)
                        results[word] = definition
                    except ValueError:
                        pass
        except IOError as err:
            print('Error reading from file.', err, file=sys.stderr)

        return results


if __name__ == '__main__':
    webster = Webster.read_data('resources', 'dictionary.txt')
    print(webster['Sample'])
