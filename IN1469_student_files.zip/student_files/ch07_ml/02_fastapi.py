"""
    02_fastapi.py

    The following is the deployed implementation of our logistic regression.
    After starting the server:
      1. Visit: localhost:8000/docs
      2. Select "Try it out"
      3. Modify the JSON data structure (e.g., set pclass to 3, for example)
      4. Click "Execute"

"""
import joblib
import pydantic
import uvicorn
from fastapi import FastAPI


class Passenger(pydantic.BaseModel):
    pclass: int
    sibsp: int
    parch: int
    who: int


app = FastAPI()
joblib_file = open('model.joblib', 'rb')
model = joblib.load(joblib_file)


@app.post('/titanic/predict')
def predict(data: Passenger):
    prediction = model.predict([[data.pclass, data.sibsp, data.parch, data.who]])
    return {'result': 'survived' if prediction[0] else 'did not make it'}


uvicorn.run(app, host='127.0.0.1', port=8000)
