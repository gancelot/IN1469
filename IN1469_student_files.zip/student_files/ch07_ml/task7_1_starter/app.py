"""
    task7_1_starter/app.py

"""
import joblib
import pydantic
import uvicorn
from fastapi import FastAPI

# Step 5. Create the Pydantic model called Person.  Inherit from BaseModel.  Provide four
#         fields: weight (int), height (float), gender (int), t_size(int)


# Step 6. Instantiate the FastAPI() server object.
#         open the joblib file using open() and mode 'rb'
#         Save the returned file handle in a variable.
#         Call joblib.load() passing the file handle into it. load() returns the model.


# Step 7. Use the app.post() decorator.
#         Supply '/person/predict' as the path argument to the decorator.
#         Create a function called predict() that accepts a person: Person parameter.
#         Perform a model.predict() call within that function passing the data values
#         from the person parameter (assumes the name data):
#         [[data.weight, data.height, data.t_size]]
#         and return a result of either 'male' or 'female' depending on the value of the
#         prediction[0].


# Step 8. Call uvicorn.run() passing the app object from step 6.
#         Supply host='127.0.0.1' and port=8000 arguments also.
#         Clean up any perceived errors and run this file.  Open the browser,
#         browse to localhost:8000/docs and test the predict method.

