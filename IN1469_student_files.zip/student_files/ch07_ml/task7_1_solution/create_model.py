"""
    task7_1_solution/create_model.py

"""
import joblib
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression

data = [
    [180, 6, 'male', 'XL'],
    [190, 5.9, 'male', 'XL'],
    [210, 5.7, 'male', 'XXL'],
    [220, 5.9, 'male', 'XXL'],
    [170, 5.6, 'male', 'L'],
    [165, 5.9, 'male', 'L'],
    [100, 5.0, 'female', 'XS'],
    [120, 5.2, 'female', 'S'],
    [130, 5.3, 'female', 'M'],
    [150, 5.6, 'female', 'M'],
    [155, 5.7, 'female', 'L'],
    [165, 5.6, 'female', 'L'],
    [170, 5.5, 'female', 'XL']
]

personal_data = pd.DataFrame(data, columns=['weight', 'height', 'gender', 'tsize'])
# Scikit-learn encoding
personal_data['gender_enc'] = LabelEncoder().fit_transform(personal_data.gender)
# Pandas encoding
personal_data.tsize = personal_data.tsize.astype('category')
personal_data['tsize_enc'] = personal_data.tsize.cat.codes
print(personal_data)

features_matrix = personal_data[['weight', 'height', 'tsize_enc']].values
response = personal_data.gender_enc.values

lgreg = LogisticRegression()
lgreg.fit(features_matrix, response)
y_pred = lgreg.predict(features_matrix)
print(lgreg.score(features_matrix, response))

joblib.dump(lgreg, 'model.joblib')
