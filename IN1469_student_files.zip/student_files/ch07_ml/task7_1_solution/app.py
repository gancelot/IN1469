"""
    task7_1_solution/app.py

"""
import joblib
import pydantic
import uvicorn
from fastapi import FastAPI


class Person(pydantic.BaseModel):
    weight: int = 0
    height: float = 0.0
    gender: int = 0
    t_size: int = 0


app = FastAPI()
joblib_file = open('model.joblib', 'rb')
model = joblib.load(joblib_file)


@app.post('/person/predict')
def predict(data: Person):
    prediction = model.predict([[data.weight, data.height, data.t_size]])
    return {'result': 'male' if prediction[0] else 'female'}


uvicorn.run(app, host='127.0.0.1', port=8000)
