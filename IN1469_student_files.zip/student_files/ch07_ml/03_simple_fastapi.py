import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel


class Person(BaseModel):
    id: int = 0
    name: str = ''
    address: str = ''


people = [
    Person(id=1, name='Sam Smith', address='123 Main St'),
    Person(id=2, name='Tina Turtle', address='456 Elm Rd'),
    Person(id=3, name='Rocky Road', address='789 Birch Ave'),
]

app = FastAPI()


@app.get('')
def read_root():
    return {'result': 'Visit /person for more.'}


@app.get('/person/{person_id}')
def read_person(person_id: int):
    matches = [person for person in people if person.id == person_id]
    if matches:
        p = matches[0]
        return p.model_dump_json()
    raise HTTPException(status_code=404, detail='No match.')


@app.put('/person/{person_id}')
def update_person(person_id: int, person: Person):
    matches = [person for person in people if person.id == person_id]

    if matches:
        p = matches[0]
        p.name = person.name
        p.address = person.address
        return p.model_dump_json()
    raise HTTPException(status_code=404, detail='No match.')


uvicorn.run(app, host='127.0.0.1', port=8000)
