"""
    01_log_reg_titanic.py

    The following performs a logistic regression on the titanic dataset to create a model
    to see if it can predict if a person would be likely to survive or not.

"""
import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.feature_selection import RFE
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

pd.set_option('display.max_columns', 20)
pd.set_option('display.width', 500)


titanic = sns.load_dataset('titanic')
titanic.replace({'who': {'man': 0, 'woman': 1, 'child': 2}}, inplace=True)
print('Columns with missing values:')
print(titanic.isnull().sum())


# Imputing...
print('Age mean: ', titanic.age.mean())
print('Age median: ', titanic.age.median())
print('If the distribution looks skewed, we will use median...')
sns.displot(titanic.age[~pd.isnull(titanic.age)])
plt.show()


imputer = SimpleImputer(strategy='median')

titanic['age'] = imputer.fit_transform(titanic.age.to_numpy().reshape(-1, 1))  # Ex: [22 38 26] --> [[22][38][26]]


print(f'Total records: {len(titanic)}')
print(titanic.head())


# Initial model...
features_matrix = titanic[['pclass', 'sibsp', 'parch', 'fare', 'who', 'age']]
response = titanic['survived']
X_train, X_test, y_train, y_test = train_test_split(features_matrix, response, random_state=42)

print('Train-to-test sizes: ', len(X_train), len(X_test))
lgreg = LogisticRegression()

lgreg.fit(X_train, y_train)
y_pred = lgreg.predict(X_test)
print(lgreg.score(X_test, y_test))


# Now to perform a little feature engineering...
rfe = RFE(estimator=lgreg, n_features_to_select=4)
rfe = rfe.fit(X_train, y_train)
print(f'RFE features: {list(X_train.columns[rfe.support_])}')


# Revised model with only top features used
lgreg = LogisticRegression()

features_matrix = titanic[['pclass', 'sibsp', 'parch', 'who']].values
response = titanic['survived'].values
X_train, X_test, y_train, y_test = train_test_split(features_matrix, response, random_state=42)

lgreg.fit(X_train, y_train)
y_pred = lgreg.predict(X_test)
print(lgreg.score(X_test, y_test))

joblib.dump(lgreg, 'model.joblib')
