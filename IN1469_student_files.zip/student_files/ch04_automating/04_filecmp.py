"""
    04_filecmp.py

    Uses filecmp to perform file comparison tasks.
    The first part compares two files with the same name but different content.
    The second part compares the difference between two directories.

"""
import filecmp
from pathlib import Path


sample = Path('sample')
print(filecmp.cmp(sample / 'quotes1/thoreau.txt', sample / 'quotes2/thoreau.txt'))
print(filecmp.cmp(sample / 'quotes1/thoreau.txt', sample / 'quotes2/thoreau.txt', shallow=False))


results = filecmp.dircmp(sample / 'quotes1', sample / 'quotes2')
results.report()

print('Left only:  ', results.left_only)
print('In Common:  ', results.common)
print('Right only: ', results.right_only)
