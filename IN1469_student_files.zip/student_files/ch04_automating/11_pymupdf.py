"""

    11_pymupdf.py       -   extract text and image info from a PDF.

"""
import logging
import sys

import fitz


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

try:
    doc = fitz.open('lorem_ipsum.pdf')
    images = []
    with open('pdf_out.txt', 'w') as txt_out:
            for page in doc:
                try:
                    txt_out.write(page.get_text())
                    images.extend(page.get_images())
                except UnicodeEncodeError:
                    pass
    doc.close()
except FileNotFoundError as err:
    logging.error(err)
    sys.exit(-1)
