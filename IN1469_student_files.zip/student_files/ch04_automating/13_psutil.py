"""

    13_psutil.py   -   Using the psutil 3rd-party tool

"""
import os

import psutil

print('% utilization: ', psutil.cpu_percent(interval=2))           # compares % utilization system wide before and after the interval
print('\nPhysical CPU cores: ', psutil.cpu_count(False))
print('\nCPU Speed: ', psutil.cpu_freq())

print('\nMemory:', psutil.virtual_memory())

print('\nPartition info: ', psutil.disk_partitions())

print('\nNetwork devices: ', psutil.net_if_addrs())

net_connections = psutil.net_connections()
print('\nNetwork sockets: ', net_connections)
print('Status of first connection: ', net_connections[0].status)

print('\nUsers: ', psutil.users())

print('\nFirst 10 process IDs: ', psutil.pids()[:10])

pid = os.getpid()
print('This process: ', pid)
p = psutil.Process(pid)
print(p, p.exe())
