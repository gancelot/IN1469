"""

    01_environ.py

"""
import os
import pprint
from pathlib import Path

pprint.pprint(dict(os.environ))

print(os.getenv('HOME'))        # Yields 'None' on Windows

print(os.path.expanduser('~'))  # works for all platforms

print(Path.home())              # gives a Path object for the user's home
print(Path('~').expanduser())

print(Path('~username').expanduser())