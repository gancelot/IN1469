"""
    08_pdfs.py

    Generates a PDF with a simple header

"""
from reportlab.lib.colors import red, black
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch

from reportlab.pdfgen.canvas import Canvas


canvas = Canvas('sample_doc.pdf', pagesize=A4, bottomup=0)

canvas.setFont('Helvetica', 20)     # also supports 'Times Roman' and 'Courier'
                                    # Bold, Italic, Oblique, and BoldOblique variations
                                    # are also supported for each font, as in:
                                    # 'Times-Italic' and 'Helvetica-Bold'

canvas.setFillColor(red)
canvas.drawCentredString(x=4.25*inch, y=1*inch, text='Sample Generated PDF')

canvas.setFont('Helvetica', 12)
canvas.setFillColor(black)
canvas.drawString(30, 110, 'Official Business')
canvas.drawString(30, 125, 'Dept. of Exchanges and Commissions')
canvas.drawString(30, 140, '27 Jun 2021')
canvas.line(25, 150, 560, 150)
canvas.save()
