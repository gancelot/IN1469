"""
        15_arrow.py

        Uses the 3rd Party tool: arrow.  To use this module:
            pip install arrow

"""
from datetime import datetime, timezone

import arrow

# these two are the same, both are preferred over today() and utcnow()
print(arrow.utcnow())
print(arrow.now())
print(arrow.now('US/Pacific'))
print(datetime.now(timezone.utc))
print(datetime.now())
print()
my_now = arrow.now()
print(my_now)
print(my_now.format())
print(my_now.format('MMM/DD/YY'))
print(my_now.humanize())
print()
print(my_now.year, my_now.day, my_now.month)
print()
some_date = arrow.get('2024-05-08 22:05:48', 'YYYY-MM-DD HH:mm:ss')
print(some_date.format('MMM DD YY'))
print(some_date.humanize())
print(arrow.utcnow().dehumanize('in a week'))
print()
extract_date = arrow.get('May I go on a march in November, 2021.', 'MMMM, YYYY')
print(extract_date.format('MMMM, YYYY'))
