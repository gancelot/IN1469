"""
    14_using_timeit.py   -   Compares StringIO and string utilization from both a
                             performance memory utilization standpoint.
"""
from io import StringIO
import timeit

import psutil


def sample_func1():
    s = 'This is our starting string'
    with StringIO() as buffer:
        for i in range(200000):
            print(s, file=buffer)
        s = buffer.getvalue()
    return len(s)


def sample_func2():
    s = 'This is our starting string'
    for i in range(200000):
        s += 'This is our starting string'
    return len(s)


print('Before StringIO: ', psutil.virtual_memory())
result = timeit.repeat(stmt='sample_func1()', globals=globals(), number=10, repeat=3)
print(result)
print('After StringIO: ', psutil.virtual_memory())

print('Before str append: ', psutil.virtual_memory())
result = timeit.repeat(stmt='sample_func2()', globals=globals(), number=10, repeat=3)
print(result)
print('After str append: ', psutil.virtual_memory())


print(sample_func1())
print(sample_func2())
