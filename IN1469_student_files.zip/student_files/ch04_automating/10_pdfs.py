"""
    10_pdfs.py
    Generates a table within a PDF using ReportLab by reading data from a file
"""
from pathlib import Path

from reportlab.lib.colors import Color, blue, lightsalmon, dimgray
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

doc_items = []

doc = SimpleDocTemplate('sample_doc3.pdf', pagesize=letter, rightMargin=72,
                        leftMargin=72, topMargin=72, bottomMargin=72)

airports = []

with Path('../resources/airports.dat').open(encoding='utf-8') as f:
    for count, line in enumerate(f):
        if count > 500:
            break
        fields = line.split(',')
        name, city, country, code = fields[1], fields[2], fields[3], fields[4]
        airports.append((name.strip('\"'), city.strip('\"'), country.strip('\"'), code.strip('\"')))

table = Table(airports, colWidths=(200, 150, 100, 60))
ts = TableStyle([('ALIGN', (0, 0), (-1, 0),'CENTER'),
                 ('TEXTCOLOR',(0, 0), (-1, 0), blue),
                 ('ALIGN', (0, 1), (-1, -1),'LEFT'),
                 ('GRID', (0, 0), (-1, -1), 1, dimgray),
                 ('BACKGROUND', (0, 0), (-1, 0), lightsalmon),
                 ('BACKGROUND', (0, 1), (-1, -1), Color(0.9, 0.95, 0.88))
])

table.setStyle(ts)
doc_items.append(table)
doc.build(doc_items)
