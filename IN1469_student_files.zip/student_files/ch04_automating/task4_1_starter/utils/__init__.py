# Step 4. Add a shortcut for the copy_files() function here.

# Step 8. Add a shortcut to the line above for the delete_common() function
