"""
        files.py -      Provides the copy_files() function which returns a
                        list of duplicate files.
"""
import filecmp
import shutil
from pathlib import Path


def copy_files(src: str | Path, dst: str | Path) -> list[str]:
    """
        This function copies files from src to dst.
        :param src: Directory of files to be copied (string)
        :param dst: Directory for destination of files (string)
        :return: The files that were copied (list)
    """
    # Step 1. Wrap both the src and dst locations in a Path() object and then
    #         check that both the src and dst directories exist.  Use Path().exists().
    #         If src does not exist, raise an OSError().
    #         If dst does not exist, use Path().mkdir() to create it.

    # Step 2. Compare the two directories using filecmp.dircmp(). The files on the left_only
    #         should be copied to the destination directory.

    # Step 3. Iterate over the list of files returned from step 2.
    #         Create a new Path() object that joins the filename and src directory
    #         and use shutil's copy2() function to copy files.
    #         Partial example:
    #               for filename in left_side:
    #                   fullpath = src / filename
    #
    #         Return a list of the files that were copied



# Step 7. This time, on your own, create a function called delete_common() that
#         deletes common files from either the dst or src directory (depending on the value of
#         a Boolean third parameter)
#         This function will be nearly identical to copy_files().  You should wrap the
#         src and dst, check if the two exist, use dircmp().common to see which files are in
#         common, iterate through the common files and call .unlink() on each one, which removes
#         them.  Return a list of the files removed.
#
#         See if you can create this function on your own.
