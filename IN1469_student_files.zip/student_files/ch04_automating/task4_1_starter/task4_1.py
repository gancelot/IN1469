# Step 5. Import copy_files() from the shortcut location.

quotes1 = '../sample/quotes1'
quotes2 = '../sample/quotes2'

# Step 6. Call the copy files function, passing the provided directories.  Display
#         the number of files copied

# Step 9. Import the delete_common() function.
#         Call delete_common() passing in the provided directories.  Display the number
#         of files deleted.


