"""
    07_attachments.py

    To simulate sending an email with an attachment to an SMTP server, you can
    run a local server that will receive and display the messages.

    To do this, from a command-line, run the command:

        python -m smtpd -c DebuggingServer -n localhost:1025      (<=Python 3.11)
        or
        python -m aiosmtpd -n -l localhost:1025                   (>=Python 3.12)

    Be sure to pip install aiosmtpd first if using Python 3.12.
"""
from pathlib import Path
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

sender = 'joe@example.com'
receiver = 'dave@example.com'

email_msg = MIMEMultipart()

email_msg['Subject'] = 'Email with attachment'
email_msg['From'] = 'admin@example.com'
email_msg['To'] = 'info@example.com'

attachment = Path(__file__)
part = MIMEApplication(attachment.read_text(), Name=attachment.name)
part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
email_msg.attach(part)

server = smtplib.SMTP('localhost', 1025)
server.send_message(email_msg)
server.quit()
