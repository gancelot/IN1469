"""

    03_shelve.py

"""
import shelve
from pathlib import Path

prefs = Path(__file__).parent / 'prefs.dat'
with shelve.open(str(prefs)) as sh:
    sh['data_dir'] = Path('..') / 'resources'
    sh['data_file'] = 'poe.txt'

with shelve.open(str(prefs)) as sh:
    file_location = sh['data_dir'] / sh['data_file']
    if file_location.exists():
        print(file_location.read_text())
