"""

    05_zipfile.py

"""
from pathlib import Path
from zipfile import ZipFile

zipfile = Path('quotes.zip')
filepath = Path(__file__).parent / 'sample/quotes1/thoreau.txt'

with ZipFile(zipfile, 'w') as fzip:
    fzip.write(filepath, arcname=filepath.name)

with ZipFile(zipfile) as fzip:
    fzip.extractall()
