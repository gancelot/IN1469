"""
    06_email.py

    To simulate sending a message to an SMTP server, you can
    run a local server that will receive and display the messages.

    To do this, from a command-line, run the command:

        python -m smtpd -c DebuggingServer -n localhost:1025      (<=Python 3.11)
        or
        python -m aiosmtpd -n -l localhost:1025                   (>=Python 3.12)

    Be sure to pip install aiosmtpd first if using Python 3.12.
"""

from pathlib import Path
import smtplib
from email.message import EmailMessage

message_body = Path('../resources/sample_message.txt')
email_msg = EmailMessage()
email_msg.set_content(message_body.read_text())

email_msg['Subject'] = 'Sample Message'
email_msg['From'] = 'joe@example.com'
email_msg['To'] = 'john@example.com'

server = smtplib.SMTP('localhost', 1025)
server.send_message(email_msg)
server.quit()
