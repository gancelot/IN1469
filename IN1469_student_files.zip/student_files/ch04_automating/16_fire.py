"""
        16_fire.py

        Get the results from reading the specified file back to the command line.

        1. pip install fire
        2. Run from the command line (or Run > Edit Configurations... within PyCharm):
               python 16_fire.py --filename somefile.txt read
               python 16_fire.py --filename somefile.txt --count 2 read
               python 16_fire.py --filename somefile.txt --count 2 read --header True
               python 16_fire.py --filename requirements.txt read --dir ..
"""
from itertools import islice
import os

import fire


class FileReader:
    def __init__(self, filename, dir=os.getcwd(), count:int = 10, header: bool = False):
        self.filename = filename
        self.dir = dir
        self.count = count
        self.header = header

        self.results = []

    def read(self):
        with open(os.path.join(self.dir, self.filename), encoding='utf-8') as f:
            if self.header:
                f.readline()
            for line in islice(f, self.count):
                self.results.append(line.strip().split(','))

        return self.results


fire.Fire(FileReader)

