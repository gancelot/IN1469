"""
    Task 4-2: Generate a PDF of the name, city, and state of the schools
    listed in the resources/baseball/Schools.csv file.
    Send this PDF as an email attachment to our "dev" SMTP server

    Don't forget to run the SMTP server before testing your script using:

        python -m smtpd -c DebuggingServer -n localhost:1025      (<=Python 3.11)
        or
        python -m aiosmtpd -n -l localhost:1025                   (>=Python 3.12)

    NOTE: if the smtpd server gives a deprecation warning, just ignore this!

"""
import logging
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from pathlib import Path

from reportlab.lib.colors import Color, green, lavenderblush, dimgray
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

import resources.gui as gui

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def get_data(filepath: str | Path) -> list[tuple]:
    data = [('Name', 'City', 'State')]
    with Path(filepath).open(encoding='utf-8') as f:
        f.readline()
        for line in f:
            fields = line.split(',')
            if len(fields) == 5:
                name, city, country = fields[1], fields[2], fields[3]
                data.append((name, city, country))
    logger.info(f'Data loaded from {filepath}')
    return data


def generate_pdf(data: list[tuple], filename: str | Path) -> None:
    doc_items = []

    doc = SimpleDocTemplate(str(filename), pagesize=letter, rightMargin=72,
                            leftMargin=72, topMargin=72, bottomMargin=72)

    table = Table(data, colWidths=(250, 200, 60))

    table_style_format = [
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),                           # Header alignment
        ('TEXTCOLOR', (0, 0), (-1, 0), green),                          # Header text
        ('BACKGROUND', (0, 0), (-1, 0), lavenderblush),                 # Header background color
        ('ALIGN', (0, 1), (-1, -1), 'LEFT'),                            # Data (body) alignment
        ('GRID', (0, 0), (-1, -1), 1, dimgray),                         # Data (body) gridlines on
        ('BACKGROUND', (0, 1), (-1, -1), Color(0.94, 0.92, 0.90))       # Data (body) background color
    ]

    ts = TableStyle(table_style_format)
    table.setStyle(ts)
    doc_items.append(table)
    doc.build(doc_items)
    logger.info(f'{filename} generated.')


def send_email(sender: str, receiver: str, subj: str, attachment_fn: str | Path) -> bool:
    status = False
    email_msg = MIMEMultipart()

    email_msg['Subject'] = subj
    email_msg['From'] = sender
    email_msg['To'] = receiver

    try:
        attachment = Path(attachment_fn)
        part = MIMEApplication(attachment.read_text(), Name=attachment.name)
        part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
        email_msg.attach(part)

        server = smtplib.SMTP('localhost', 1025)
        server.send_message(email_msg)
        server.quit()
        logger.info('Email and attachment sent.')
        status = True
    except ConnectionRefusedError:
        logger.error(f'Email not sent.  Your server is likely not running.')
    except Exception as err:
        logger.error('Email not sent.')
        logger.error(f'{type(err)}: {err}')

    return status


if __name__ == '__main__':

    logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                        handlers=[logging.StreamHandler(stream=sys.stdout)])

    data_file = '../resources/baseball/Schools.csv'
    result = gui.simple_input(default_input_value=data_file)
    if result:
        data_file = Path(data_file)
        pdf_file = Path(data_file.stem + '.pdf')
        file_data = get_data(result)
        generate_pdf(file_data, pdf_file)
        if send_email(sender='joe@example.com', receiver='dave@example.com',
                      subj='Task4-2 with PDF Attachment', attachment_fn=str(pdf_file)):
            logger.info('Email sent.')
    else:
        logger.info('Action canceled.')
