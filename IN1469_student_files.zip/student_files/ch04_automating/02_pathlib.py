"""
    02_pathlib.py

    Demonstrates the use of pathlib and fnmatch.

"""
import fnmatch
from pathlib import Path

p = Path(__file__)
print(p)
print(p.parent)
print(p.parents[0])
print(p.parents[1])

print(p.name)
print(p.stem)
print(p.suffix)
print(p.drive)

resources_dir = p.parents[1] / 'resources'


# -----------using Path and fnmatch()---------
print('\nWorking with Path and fnmatch(): ')
pattern = 'c*.txt'
print(f'File matches for {pattern} in {resources_dir}:')
for filepath in resources_dir.iterdir():
    if fnmatch.fnmatch(filepath.name, pattern):
        print(filepath.name)
