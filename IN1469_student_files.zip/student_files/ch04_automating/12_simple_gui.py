"""

    12_simple_gui.py   -   A demo of the PySimpleGUI library.
                           The resources folder in the student files provides a wrapper
                           around these functions making it even easier to use.
                           For more on this wrapper, see gui.py in the resources folder.

"""
import PySimpleGUI as sg


layout = [
             [sg.Text('Value')],
             [sg.InputText()],
             [sg.Submit(), sg.Cancel()]
         ]

window = sg.Window('Query', layout)
event, results = window.read()
window.close()

print(event, results[0])

sg.popup('Results:', results[0])
