"""
    Task 4-2 (Starter)
    Generate a PDF of the name, city, and state of the schools
    listed in the resources/baseball/Schools.csv file.

    Send this PDF as an email attachment to our "dev" SMTP server.

    Step 1. From a command window, start the SMTP server depending on your Python version:

        python -m smtpd -c DebuggingServer -n localhost:1025      (<=Python 3.11)
        or
        python -m aiosmtpd -n -l localhost:1025                   (>=Python 3.12)

        NOTE: if the smtpd server gives a deprecation warning, just ignore this!

    Step 2. Examine the get_data() function below.  It is already completed and
            should successfully return the data from the file.  At the bottom of this
            file, the get_data() function is called.

    Step 3. Complete the generate_pdf() function.  You can alter and/or experiment with
            the TableStyle parameters as you see fit.  To finish this function, at
            the bottom of it:
            a) Add the TableStyle object to the Table (hint: call setStyle()).
            b) Append the Table object to the PDF doc_items to be rendered.
            c) Call the SimpleDocTemplate's build() method passing the doc_items to it.

    Step 4. Call the generate_pdf() function at the bottom, after the call to get_data()

    Step 5. Complete the send_email() function.
            a) Add Subject, From, and To entries to our email object. Assign them to
               our passed in values:
                    email_msg['Subject'] =
                    email_msg['From'] =
                    email_msg['To'] =

            b) Start your SMTP server at the location indicated 'Step 5b.'
               Send the message (hint: server.send_message(email_msg)
               End (quit) the server


    Step 6. In an if-control, call the send_email() function at the bottom, after the call
            to generate_pdf().
            a) Pass into the function a (fictitious) sender and receiver email address
            b) Pass a subject
            c) Pass the name of our newly created PDF file
            d) In the if-control body, simply log the successful email being sent
               using logger.info()

            That's it, test it out and troubleshoot as necessary!
"""
import logging
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from pathlib import Path

from reportlab.lib.colors import Color, green, lavenderblush, dimgray
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

import resources.gui as gui

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def get_data(filepath: str | Path) -> list[tuple]:
    data = [('Name', 'City', 'State')]
    with Path(filepath).open(encoding='utf-8') as f:
        f.readline()
        for line in f:
            fields = line.split(',')
            if len(fields) == 5:
                name, city, state = fields[1], fields[2], fields[3]
                data.append((name, city, state))
    logger.info(f'Data loaded from {filepath}')
    return data


def generate_pdf(data: list[tuple], filename: str | Path) -> None:
    doc_items = []

    doc = SimpleDocTemplate(str(filename), pagesize=letter, rightMargin=72,
                            leftMargin=72, topMargin=72, bottomMargin=72)

    table = Table(data, colWidths=(250, 200, 60))

    table_style_format = [
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),  # Header alignment
        ('TEXTCOLOR', (0, 0), (-1, 0), green),  # Header text
        ('BACKGROUND', (0, 0), (-1, 0), lavenderblush),  # Header background color
        ('ALIGN', (0, 1), (-1, -1), 'LEFT'),  # Data (body) alignment
        ('GRID', (0, 0), (-1, -1), 1, dimgray),  # Data (body) gridlines on
        ('BACKGROUND', (0, 1), (-1, -1), Color(0.94, 0.92, 0.90))  # Data (body) background color
    ]

    ts = TableStyle(table_style_format)

    # Step 3 here

    logger.info(f'{filename} generated.')


def send_email(sender: str, receiver: str, subj: str, attachment_fn: str | Path) -> bool:
    status = False
    email_msg = MIMEMultipart()

    # Step 5a. here

    try:
        attachment = Path(attachment_fn)
        part = MIMEApplication(attachment.read_text(), Name=attachment.name)
        part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
        email_msg.attach(part)

        # Step 5b. here

        logger.info('Email and attachment sent.')
        status = True
    except ConnectionRefusedError:
        logger.error(f'Email not sent.  Your server is likely not running.')
    except Exception as err:
        logger.error('Email not sent.')
        logger.error(f'{type(err)}: {err}')

    return status


if __name__ == '__main__':

    logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                        handlers=[logging.StreamHandler(stream=sys.stdout)])

    data_file = '../resources/baseball/Schools.csv'
    result = gui.simple_input(default_input_value=data_file)
    if result:
        data_file = Path(data_file)
        pdf_file = Path(data_file.stem + '.pdf')
        file_data = get_data(result)
        # Step 4. Call generate_pdf() passing the file data and pdf file as parameters

        # Step 6. Call send_email() in an if-statement.  log an info() call if the
        #         if statement is True
    else:
        logger.info('Action canceled.')
