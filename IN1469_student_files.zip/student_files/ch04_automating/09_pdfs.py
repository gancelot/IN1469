"""
    09_pdfs.py
    Generates text within a PDF by reading data from a file

"""
from pathlib import Path

from reportlab.lib.colors import blue, black
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer


doc = SimpleDocTemplate('sample_doc2.pdf', pagesize=letter, rightMargin=72,
                        leftMargin=72, topMargin=72, bottomMargin=72)
doc_items = []
fontsize = 12


with Path('../resources/alice.txt').open() as f:
    for line in f:
        line = line.strip()
        if len(line) >= 1:
            if 'Alice' in line:
                parts = line.split('Alice')
                line = f'<font size="{fontsize}" color="{black}">{parts[0]}</font><font size="{fontsize}" color="{blue}">Alice</font><font size="{fontsize}" color="{black}">{parts[1]}</font>'
            else:
                line = f'<font size="{fontsize}" color="{black}">{line}</font>'
            doc_items.append(Paragraph(line))
        else:
            doc_items.append(Spacer(1, 12))

doc.build(doc_items)
