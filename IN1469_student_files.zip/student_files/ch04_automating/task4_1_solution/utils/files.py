"""
        files.py -      Provides the copy_files() function which returns a
                        list of duplicate files.
"""
import filecmp
import shutil
from pathlib import Path


def copy_files(src: str | Path, dst: str | Path) -> list[str]:
    """
        This function copies files from src to dst.
        :param src: Directory of files to be copied (string)
        :param dst: Directory for destination of files (string)
        :return: The files that were copied (list)
    """
    src = Path(src)
    dst = Path(dst)

    if not src.exists():
        raise OSError('Source directory not found.')

    if not dst.exists():
        dst.mkdir()

    left_only = filecmp.dircmp(src, dst).left_only

    copied = []
    for filename in left_only:
        fullpath = src / filename
        if fullpath.is_file():
            shutil.copy2(fullpath, dst)
            copied.append(filename)

    return copied


def delete_common(src: str | Path, dst: str | Path, from_dst: bool = True) -> list[str]:
    """
        Addon to our task.  Uses Path() objects again, deletes common files from the
        destination (by default) or the source if from_dst=False.
    """
    src = Path(src)
    dst = Path(dst)

    if not src.exists():
        raise OSError('Source directory not found.')

    if not dst.exists():
        raise OSError('Source directory not found.')

    common = filecmp.dircmp(src, dst).common

    removed = []
    for filename in common:
        fullpath = dst/filename if from_dst else src/filename
        fullpath.unlink()
        removed.append(fullpath.name)
    return removed
