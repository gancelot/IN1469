from utils import copy_files, delete_common

quotes1 = '../sample/quotes1'
quotes2 = '../sample/quotes2'

results = copy_files(quotes1, quotes2)
print(f'{len(results)} files copied: {results}.')

results = delete_common(quotes1, quotes2)
print(f'{len(results)} files deleted: {results}.')
