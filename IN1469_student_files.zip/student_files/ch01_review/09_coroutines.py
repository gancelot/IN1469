"""

    09_coroutines.py - shows how generators work to "receive" values repeatedly

"""
from pathlib import Path
from typing import Generator

import click


def write_msg(filepath: Path | str) -> Generator[None, str, None]:
    with open(filepath, 'wt', encoding='utf-8') as f:
        msg = yield
        while msg:
            print(msg, file=f)
            msg = yield


filename = 'coroutine_messages.txt'
write_coroutine = write_msg(filename)
next(write_coroutine)

message = click.prompt('Enter message to save (enter to quit)', default='', show_default=False)
while message:
    write_coroutine.send(message)
    message = click.prompt('Enter message to save (enter to quit)', default='', show_default=False)
