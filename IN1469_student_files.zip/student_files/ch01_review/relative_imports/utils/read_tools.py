from contextlib import contextmanager
from pathlib import Path


@contextmanager
def read_utf8(filepath: str | Path):
    f = open(filepath, encoding='utf-8')
    try:
        yield f
    finally:
        f.close()
