"""
    relative_imports/07_packages.py

    Demonstrates __init__.py and the use of relative imports and import shortcuts
"""
import sys
from itertools import islice
from pathlib import Path

from ch01_review.relative_imports.utils import read_utf8

filepath = Path(__file__).parents[2] / 'resources/poe.txt'
try:
    with read_utf8(filepath) as f:
        for line in islice(f, 81, 89):
            print(line.rstrip())
except IOError as err:
    print(err, file=sys.stderr)
