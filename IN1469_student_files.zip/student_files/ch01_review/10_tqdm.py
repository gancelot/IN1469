"""
        10_tqdm.py

        Uses the 3rd Party tool: tqdm.  To use this module:
            pip install tqdm (unless using Anaconda)

"""
from warnings import filterwarnings
from pathlib import Path

import pandas as pd
import tqdm

filterwarnings('ignore')                # hides RuntimeWarnings caused by NaN division as they aren't relevant here

avgs = []
filepath = Path(__file__).parents[1] / 'resources/baseball/Batting.csv'

batting = pd.read_csv(filepath, usecols=['yearID', 'AB', 'H'])

for idx, row in tqdm.tqdm(batting.iterrows(), total=batting.shape[0]):
    avg = row['H'] / row['AB']
    avgs.append(avg)
print(f'{len(avgs)} rows operated on.')
