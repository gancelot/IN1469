"""
    08_argparse.py - demonstrates the use of the argparse module.

    Reads a limited set of lines from a data file.  Optionally reads or ignores the header
    dir = The directory to look within.  (position, optional value) (default current directory)
    filename = The name of the file to open.  (positional, required value)
    -c (--count) = how many lines to read (default 20)
    -r (--remove_header) = Whether to strip the first line as a header (default False).  Field renamed to header.

    Example command-line (terminal) usage (from the within ch01_review folder):
    Use:    python 08_argparse.py ../resources titanic.csv -c 5 -r

"""
from argparse import ArgumentParser
from itertools import islice
import os


def get_args():
    parser = ArgumentParser()
    parser.add_argument('dir', default=os.getcwd(), nargs='?')
    parser.add_argument('filename')
    parser.add_argument('-c', '--count', default=20, type=int)
    parser.add_argument('-r', '--remove_header', action='store_true', default=False, dest='header')
    return parser.parse_args()


args = get_args()
print(f'Args provided: ', args)

results = []
with open(os.path.join(args.dir, args.filename), encoding='utf-8') as f:
    if args.header:
        f.readline()
    for line in islice(f, args.count):
        results.append(line.strip().split(','))

for record in results:
    print(record)
