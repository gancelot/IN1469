"""
    02_database_print.py

    This version is the same as 02_database.py except that it doesn't use PrettyTable and
    therefore doesn't retain records retrieved from the database.  Instead, it prints them
    and moves on to the next record.  This version will use less overhead than the previous
    version.
"""
import logging
import sqlite3
import sys
from pathlib import Path
from typing import Generator


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

database = Path(__file__).parents[1] / 'resources/course_data.db'


def retrieve_records(config_params: dict, stmt: str, stmt_params: tuple) -> Generator[tuple, None, None]:
    """Generator to connects to and iterates over database data.

    :param config_params: (dict) - database connection values
    :param stmt: (str) - SQL query statement
    :param stmt_params: (tuple | list) - SQL params to be filled in for ?
    :return: None
    """
    connection = None
    try:
        connection = sqlite3.connect(**config_params)
        cursor = connection.cursor()

        cursor.execute(stmt, stmt_params)

        for row in cursor:
            yield row
    except sqlite3.Error as err:
        print(err, file=sys.stderr)
    finally:
        if connection:
            connection.close()
            logging.info('Connection closed.')          # this is the root (and only, in this case) logger


config = {'database': database}
statement = 'select carat, cut, color from diamonds where price > ?'
params = (18000,)
for record in retrieve_records(config, statement, params):
    print(record)
