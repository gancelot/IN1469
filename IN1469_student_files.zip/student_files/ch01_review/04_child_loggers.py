"""
        04_child_loggers.py

        This example creates 3 hierarchical loggers:    root                (level: warning)
                                                        __main__            (level: inherited)
                                                        __main__.child      (level: inherited)

        If you know the name of a logger, you can simply call logging.getLogger(<name>) to
        obtain it.  This way loggers don't actually have to be passed around.
        Also, since root logger defines both console and file handlers, children loggers
        will incur this setting unless they override it.
"""
import logging
import sys


logging.basicConfig(level=logging.WARNING,
                    handlers=[logging.FileHandler('root.log'),
                              logging.StreamHandler(stream=sys.stdout)])

root_logger = logging.getLogger()
child_of_root = logging.getLogger(__name__)
child_of_child_of_root = logging.getLogger(f'{child_of_root.name}.child')

print(f'Loggers: {root_logger.name}, {child_of_root.name}, {child_of_child_of_root.name}')


def add(x, y):
    logging.getLogger().debug('add called')                                 # root, won't occur, level too low
    logging.getLogger(__name__).info(f'add({x}, {y})')                      # won't occur, inherited root's level
    logging.getLogger(f'{__name__}.child').warning(f'Arguments: {x}, {y}')  # will occur
    return x + y


result = add(5, 6)
