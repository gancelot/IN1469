import logging
import pprint
import sys
import time
from argparse import ArgumentParser
from pathlib import Path

from tqdm import tqdm

from utils import find_neighbors


def get_args():
    parser = ArgumentParser()
    parser.add_argument('names', nargs='*', default=['US'], help='Example: US DE IN')
    return parser.parse_args()


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

database = Path(__file__).parents[3] / 'resources/course_data.db'
params = {'database': database}

countries = get_args()

neighbor_coroutine = find_neighbors(params)
for name in countries.names:
    next(neighbor_coroutine)
    print(neighbor_coroutine.send(name.upper()))

results = []
for name in tqdm(countries.names):
    time.sleep(1)
    next(neighbor_coroutine)
    results.append(neighbor_coroutine.send(name.upper()))
pprint.pp(results)
