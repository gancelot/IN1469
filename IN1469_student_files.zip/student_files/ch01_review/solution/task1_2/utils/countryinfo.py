import logging
from typing import Generator

from . import get_connection

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def countryinfo(db_params: dict) -> dict[str, tuple]:
    info = {}
    try:
        with get_connection(db_params) as connection:
            cursor = connection.cursor()
            cursor.execute('select iso, iso3, country, capital, neighbours from countryinfo')
            for iso, *remaining in cursor:
                info[iso] = remaining
    except Exception as err:
        if err.__cause__:
            logger.error(f'Root cause: {err.__cause__}')
        logger.error(f'Error messages: {err.args}')

    return info


def find_neighbors(db_params: dict) -> Generator[list, str, None]:
    empty_set = ['', '', '', '']
    country_info = countryinfo(db_params)

    while True:
        next_country = yield
        if not next_country:
            break
        info = country_info.get(next_country, empty_set)
        neighbors = info[3].split(',')
        yield [country_info.get(neighbor, empty_set)[1] for neighbor in neighbors]
