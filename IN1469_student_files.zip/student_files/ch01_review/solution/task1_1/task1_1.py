import logging
import sys
from pathlib import Path

from utils import get_connection


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def countryinfo(db_params: dict) -> dict[str, tuple]:
    info = {}
    try:
        with get_connection(db_params) as connection:
            cursor = connection.cursor()
            cursor.execute('select iso, iso3, country, capital, neighbours from countryinfo')
            for iso, *remaining in cursor:
                info[iso] = remaining
    except Exception as err:
        if err.__cause__:
            logging.error(f'Root cause: {err.__cause__}')
        logging.error(f'Error messages: {err.args}')

    return info


database = Path(__file__).parents[3] / 'resources/course_data.db'
params = {'database': database}
country_info = countryinfo(params)
print(f'{len(country_info)} countries found.')
