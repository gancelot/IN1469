import logging
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


@contextmanager
def get_connection(connect_params: dict) -> Generator[sqlite3.Connection, None, None]:
    """

    :param connect_params: (dict) sqlite3 should provide a 'database' key to describe the path to the db

    """
    connection = None
    try:
        connection = sqlite3.connect(**connect_params)
        logger.debug('DB connection obtained.')
        yield connection
    except sqlite3.Error as err:
        raise Exception('Invalid connection parameters.', connect_params) from err
    finally:
        if connection:
            connection.close()
            logger.debug('DB connection closed.')


if __name__ == '__main__':
    path = Path(__file__).parents[4] / 'resources/course_data.db'
    with get_connection({'database': path}) as conn:
        assert isinstance(conn, sqlite3.Connection)
