"""
    02_database.py

    Demonstration of the use of generators, logging configuration,
    and Python Database API.
"""
import logging
import sqlite3
import sys
from pathlib import Path
from typing import Generator

from prettytable import PrettyTable


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

database = Path(__file__).parents[1] / 'resources/course_data.db'


def retrieve_records(config_params: dict, stmt: str, stmt_params: tuple) -> Generator[tuple, None, None]:
    """Generator to connects to and iterates over database data.

    :param config_params: (dict) - database connection values
    :param stmt: (str) - SQL query statement
    :param stmt_params: (tuple | list) - SQL params to be filled in for ?
    :return: None
    """
    connection = None
    try:
        connection = sqlite3.connect(**config_params)
        cursor = connection.cursor()

        cursor.execute(stmt, stmt_params)

        for row in cursor:
            yield row
    except sqlite3.Error as err:
        print(err, file=sys.stderr)
    finally:
        if connection:
            connection.close()
            logging.info('Connection closed.')


config = {'database': database}
statement = 'select carat, cut, color from diamonds where price > ?'
params = (18000,)
pt = PrettyTable(['carat', 'cut', 'color'])
for record in retrieve_records(config, statement, params):
    pt.add_row(record)
print(pt)
