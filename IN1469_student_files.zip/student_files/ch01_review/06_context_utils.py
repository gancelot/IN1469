"""
    06_context_utils.py

    Demonstrates the @contextmanager utility from the contextlib module.
"""
import sys
from contextlib import contextmanager
from itertools import islice
from pathlib import Path


@contextmanager
def read_utf8(filepath: str | Path):
    f = open(filepath, encoding='utf-8')
    try:
        yield f
    finally:
        f.close()


filepath = Path(__file__).parents[1] / 'resources/poe.txt'
try:
    with read_utf8(filepath) as f:
        for line in islice(f, 81, 89):
            print(line.rstrip())
except IOError as err:
    print(err, file=sys.stderr)
