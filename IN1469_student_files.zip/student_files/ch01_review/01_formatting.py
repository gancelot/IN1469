"""
    01_formatting.py

    Demonstration of the use of the * and ** operators.
    Also, demonstration of formatting syntax.

"""
from typing import NamedTuple


# * notation can be used with lists, tuples, generators, dictionaries, and more
winners = ('Bob', 'Sally', 'John')
print('Top two: {0}, {1}'.format(winners[0], winners[1], winners[2]))
print('Top two: {0}, {1}'.format(*winners))


# Works for namedtuples (and typed namedtuples)
# It's okay to provide more values than are needed
Winners = NamedTuple('Winners', [('first', str), ('second', str), ('third', str)])
winners = Winners('Bob', 'Sally', 'John')
print('Top two: {0}, {1}'.format(winners.first, winners.second, winners.third))
print('Top two: {0}, {1}'.format(*winners))


# dictionaries can use the ** unpack operator
winners = {'first': 'Bob', 'second': 'Sally', 'third': 'John'}
print('Top two: {first}, {second}'.format(first=winners['first'],
                                          second=winners['second'],
                                          third=winners['third']))
print('Top two: {first}, {second}'.format(**winners))


# numbers can be represented with underscores for ease of readability
# extra formatting syntax shown here including the use of f-strings
distance = 240_000
print('Format examples:')
print('Distance: {0:,.3f}'.format(distance))
print('Distance: {dist:_^+20,}'.format(dist=distance))
print(f'Distance: {distance:_^+20,.3f} miles')

print('\nNesting f-string syntax:')
distance = 240_000
field_width = 25
print(f'Distance: {distance:_^+{field_width},.3f}')
