"""
    03_generators.py

    generator1() below shows how the generator pauses and picks up where it left off.

    read_definitions() parses a file lazily, retrieving dictionary word definitions iteratively

    The last example demonstrates a generator expression but limits the iterating to 50 times.
"""
from itertools import islice
from pathlib import Path


def generator1():
    count = 1
    print(f'Generator paused. Count={count}')
    yield count

    count += 1
    print(f'Generator paused again. Count={count}')
    yield count

    count += 1
    print(f'Generator paused one last time. Count={count}')
    yield count


for value in generator1():
    print(value)


def read_definitions(filepath: Path):
    try:
        with open(filepath, encoding='utf-8') as f:
            for line in f:
                try:
                    word, definition = line.strip().split(maxsplit=1)
                    yield word, definition
                except ValueError:
                    pass
    except IOError as err:
        print('Error reading from file.', err)


filepath = Path(__file__).parents[1] / 'resources/dictionary.txt'
for idx, (word, definition) in enumerate(read_definitions(filepath), 1):
    print(f'Word {idx}: {word:<20}{definition[:50]}')


gen_expr = (line.strip().split(maxsplit=1) for line in open(filepath, encoding='utf-8') if not line.startswith('Usage') and len(line.strip()) > 1)

for word, definition in islice(gen_expr, 50):         # only iterates 50 times
    print(f'{word:<20}{definition[:65]:<70}')
