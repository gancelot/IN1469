"""
    05_decorators.py

    Demonstrates how decorators can gain control of your functions by using the
    validate_call decorator from Pydantic.  Also demonstrates the use of the atexit
    function decorator (calls your function when the program is about to exit)

    Finally, it illustrates a generic template for the creation of decorators.

"""
import atexit
from itertools import islice
from pathlib import Path

from pydantic import ValidationError, validate_call


@validate_call(validate_return=True)
def read_definitions(filepath: str | Path, size: int = 10, encoding: str = 'utf-8') -> list[tuple[str, str]]:
    results = []
    with open(Path(filepath), encoding=encoding) as f:
        for line in islice(f, size):
            try:
                word, definition = line.strip().split(maxsplit=1)
                results.append((word, definition))
            except ValueError:
                pass
    return results


datafile = Path(__file__).parents[1] / 'resources/dictionary.txt'

try:
    print(read_definitions(datafile, 7))                              # Okay
    print(read_definitions(size='7', filepath=datafile))              # Okay, Pydantic converts int-string into int
    print(read_definitions(datafile, 'hello'))                        # Not okay
except IOError as err:
    print(f'Error reading from file {err}')
except ValidationError as err:
    print(f'Validation error: {err}')


@atexit.register
def upon_exit():
    print('exiting...')


# The basic decorator syntax...

def decorator(func):
    def wrapper(*args, **kwargs):
        print('in wrapper')
        ret_val = func(*args, **kwargs)
        return ret_val
    return wrapper


@decorator
def orig_func(msg):
    print(msg)


orig_func('hello')
