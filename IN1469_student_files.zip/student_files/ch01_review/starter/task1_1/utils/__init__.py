# Step 3. Add a shortcut to the get_connection() method created previously
