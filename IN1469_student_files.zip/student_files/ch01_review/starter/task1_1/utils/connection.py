import logging
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

# Step 1. Add the contextmanager decorator here.  Also pass in a dictionary (let's call it connect_params).
#         Optionally add a return type annotation for this generator where the yield will be a Connection object.
#         (see student notes for more on annotations for generators)
def get_connection():
    connection = None
    try:
        # Step 2a. Get a connection object from the sqlite3 module's connect() method passing the dictionary into it.
        #         yield the connection (Also, put a debug log statement here indicating the connection was obtained.)
    except sqlite3.Error as err:
        # Step 2b. For any exceptions, use raise Exception() from with an appropirate message.
    finally:
        # Step 2c. Close the connection. (Check that it exists first.  Also, log that the connection was closed.)

if __name__ == '__main__':
    path = Path(__file__).parents[4] / 'resources/course_data.db'
    # Step 2d. Test our get_connection() method above by passing it into a with control.
    #          supplying a dictionary of {'database': path} then perform an assertion:
    #          assert isinstance(conn, sqlite3.Connection)
