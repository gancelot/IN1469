import logging
import sys
from pathlib import Path

# Step 4. Import the get_connection() function from the shortcut.


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])


def countryinfo(db_params: dict) -> dict[str, tuple]:
    info = {}
    try:
        # Step 5. Use get_connection() in a with control passing the db params.
        #         into it.  Obtain a cursor and execute the provided SQL statement.
        #         'select iso, iso3, country, capital, neighbours from countryinfo'

        # Step 6. Iterate over the cursor. Place each record into a dictionary as follows:
        #         info[iso] = [remaining items]

    except Exception as err:
        if err.__cause__:
            logging.error(f'Root cause: {err.__cause__}')
        logging.error(f'Error messages: {err.args}')

    return info


database = Path(__file__).parents[3] / 'resources/course_data.db'
params = {'database': database}
# Step 7. Call the countryinfo() function.  Pass the db connection params object into it.
#         Get the results (too long to look at, just display it's len()).

