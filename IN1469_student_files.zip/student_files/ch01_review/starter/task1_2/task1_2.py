import logging
import pprint
import sys
import time
from argparse import ArgumentParser
from pathlib import Path

from tqdm import tqdm

# Step 3. Add an import for find_neighbors from the shortcut previously defined.


def get_args():
    parser = ArgumentParser()
    # Step 4a. Add an argument called 'names'.  It will have a default of ['US'] and nargs='*'.
    #          You may optionally provide a help='Example: US DE IN' argument also


    return parser.parse_args()


logging.basicConfig(level=logging.DEBUG, format='%(message)s',
                    handlers=[logging.StreamHandler(stream=sys.stdout)])

database = Path(__file__).parents[3] / 'resources/course_data.db'
params = {'database': database}

# Step 4b. Call get_args() above which returns the parsed args object
#          (a Namespace).  Save this in a variable.


# Step 5a. Invoke the coroutine passing our db params.  Capture the returned generator object.
#          neighbor_coroutine = find_neighbors(params)

# Step 5b. Iterate over each of the command-line provided names (countries.names)
#          Advance the coroutine (prime it) up to the yield using: next(neighbor_coroutine).
#          Pass a value in at the yield point and print its result:
#          print(neighbor_coroutine.send(name.upper()))



# Step 6.  Rewrite step 5 to use tqdm.  Do this by first creating a results = [] variable.
#          Then, wrap tqdm() around countries.names.
#          Next, slow the loop down a bit (so we can see the progress bar working)
#          by inserting:  time.sleep(1) into the loop.
#          Prime the coroutine (like we did in step 5 above) using: next(neighbor_coroutine).
#          Instead of printing each time, let's append() each yielded value from the generator
#          into the results array: results.append(neighbor_coroutine.send(name.upper())).
#          Pretty print the results.  pprint.pp()

