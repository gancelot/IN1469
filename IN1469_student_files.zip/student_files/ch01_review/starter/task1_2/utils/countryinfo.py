import logging
from typing import Generator

from . import get_connection

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def countryinfo(db_params: dict) -> dict[str, tuple]:
    info = {}
    try:
        with get_connection(db_params) as connection:
            cursor = connection.cursor()
            cursor.execute('select iso, iso3, country, capital, neighbours from countryinfo')
            for iso, *remaining in cursor:
                info[iso] = remaining
    except Exception as err:
        if err.__cause__:
            logger.error(f'Root cause: {err.__cause__}')
        logger.error(f'Error messages: {err.args}')

    return info


def find_neighbors(db_params: dict) -> Generator[list, str, None]:
    empty_set = ['', '', '', '']
    # Step 1a. Call the countryinfo() function above.  Pass in db_params.  Place the return
    #          value into a dictionary (call it country_info, for example)

    # Step 1b. Loop indefinitely with a while statement (e.g., while True:)
    #          Retrieve a country value (using yield on the right-hand side of an equation) that is sent in.
    #          Check if the country value sent in exists, otherwise break out of the loop

    # Step 1c. Take that country value and plug it into the country_info dictionary (e.g., info = country_info.get(...))
    #          This returns a tuple where the fourth value in that tuple is a string of neighbors.
    #          Take that string and split it up on the ',' separator as in: neighbors = info[3].split(',')

    # Step 1d. Look each country neighbor up in the dictionary (which is the second field)
    #          and either print the results or yield them back
    #          (e.g., yield [<look up country name> for neighbor in neighbors]
