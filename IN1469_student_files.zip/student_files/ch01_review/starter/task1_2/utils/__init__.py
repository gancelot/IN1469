from .connection import get_connection
# Step 2. Add a shorcut import for find_neighbors here

